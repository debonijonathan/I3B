/** 
****************************************************
@mainpage OverVision Object (OVO) file format, v0.7r
****************************************************


*******************************
@section intro_sec Introduction
*******************************

The OverVision Object (OVO) file format is the native format used by the OverVision 3D graphics engine to store and load data
from files. OVO files contain information about 3D meshes, the scenegraph, light sources, material properties and textures. It must not
be confused with the ancillary file format OverVision Anim (OVA), used for storing animations and available as a separate component. 

OVO files are typically created through the over3ds plugin for 3D Studio MAX: in this way, one can directly export 3D assets from
3D Studio MAX into a format that is natively recognized by the OverVision graphics engine.

OVO data is structured in an OpenGL-friendly way, both to be compatible with the OpenGL conventions and to reduce loading time. 
Most of the data stored within an OVO file can almost be directly copied into OpenGL buffers without any (or minimal) processing.
<br><br>


***********************************
@section fileformat_sec File format
***********************************

The OVO file format is a simple binary file composed of a series of chunks. Each chunk is defined by its ID (specifying the type of information 
it contains) and its size (to quickly move forward to the next chunk). 
<br>
For each piece of information reported in the following sections, its type and size are documented. 
In this way, moving through available data is a simple matter of increasing the current data reading offset by the size
of each element. 
<br><br>


*******************************************
@subsection chunkheader_subsec Chunk header
*******************************************
 
The chunk header is composed of two values: the chunk ID and the chunk size. To parse the file further to the next chunk, simply offset
the current position by the chunk size value. If you hit the end of the file, there are no more available chunks to parse, otherwise 
you will find the header of the next chunk. In this way, if you do not mind to process some chunk ID (either because you are not 
interested or you do not know how to handle them), you can quickly skip a chunk and move to the next one. 

| Type | Size | Description |
| :--: | :--: | :---------- |
| dword | 4 bytes | Chunk ID (see enums in class OvObject for their meaning). |
| dword | 4 bytes | Size (in bytes) of this chunck. Offset reading position by this amount to move to the next chunk. |
| byte | [chunk size] bytes | The actual data for this chunk (depends on the chunk ID value, see following sections). |
<br>


*******************************************
@subsection versiondata_subsec Version data
*******************************************
 
The version data chunk contains information about the file format revision used. Although not strictly mandatory, this chunk should be the 
first one provided in any OVO file.
 
| Type | Size | Description |
| :--: | :--: | :---------- |
| dword | 4 bytes | File format version ID. Should be 7 at the moment. |
<br>


*************************************
@subsection nodedata_subsec Node data
*************************************
 
The node chunk contains information about a specific node of the scenegraph. If this node has child nodes, following chunks of compatible types
are its content. The simplest way to correctly build a scenegraph while parsing an OVO file consists in using a recursive function, e.g.:

~~~~~~~~~~~~{.c}
// buffer = OVO file content entirely copied to memory
// position = current position within the memory buffer
Node *root = recursiveLoad(buffer, position);

// Recursive loading function:
Node *recursiveLoad(byte *buffer, unsigned int &position)
{
   // Parse the chunk starting at buffer + position:   
   unsigned int chunkSize = ... 

   // Extract node information:
   unsigned int nrOfChildren = ...
   Node *thisNode = ...
   
   // Update position for next chunk:
   position += chunkSize;
   
   // Go recursive when child nodes are avaialble:
   if (nrOfChildren)
      while (thisNode->getNrOfChildren() < nrOfChildren)
      {
         Node *childNode = recursiveLoad(buffer, position);         
         thisNode->addChild(childNode);
      }
   
   // Done:
   return thisNode;
}
~~~~~~~~~~~~
This same structure of data is also present at the beginning of each chunk that contains an object derived from the class node (i.e., mesh, light, bone). 
 
| Type | Size | Description |
| :--: | :--: | :---------- |
| byte | variable | Null terminating string containing the node name. The size of this field is given by the name length plus one (for the terminating null character). |
| float | 64 bytes | 4x4 matrix for this node, as an array of float values. |
| dword | 4 bytes | Number of child nodes. Following chunks that contain node information are the children of this node. |
| byte | variable | Null terminating string containing the target node (or "[none]" if not used). The size of this field is given by the target name length plus one (for the terminating null character). |
<br>


*********************************************
@subsection materialdata_subsec Material data
*********************************************

This chunk contains information about a material and its properties. Typically, materials are listed among the first chunks of an OVO
file to simplify data parsing, but this is not a strict rule: material chunks can be specified at any point within an OVO file and might
also describe materials that are not used by meshes of the same file. It is perfectly valid to have an entire OVO file populated exclusively
by material chunks: in this case, such a file would be conceptually more like a material library or material archive rather than 3D information. 
<br>
 
| Type | Size | Description |
| :--: | :--: | :---------- |
| byte | variable | Null terminating string containing the material name. The size of this field is given by the name length plus one (for the terminating null character). | 
| float | 12 bytes | Emissive color (RGB) as a vector of three float components. | 
| float | 12 bytes | Albedo color (RGB) as a vector of three float components. | 
| float | 4 bytes | Roughness value given as a single float (from 0.0 = flat to 1.0 = rough). | 
| float | 4 bytes | Metalness value given as a single float (from 0.0 = not metal to 1.0 = metal). | 
| float | 4 bytes | Transparency coefficient as a single float (from 0.0 = invisible to 1.0 = solid). | 
| byte | variable | Null terminating string containing the albedo map file name (or "[none]" if not used). The size of this field is given by the name length plus one (for the terminating null character). | 
| byte | variable | Null terminating string containing the normal map file name (or "[none]" if not used). The size of this field is given by the name length plus one (for the terminating null character). | 
| byte | variable | Null terminating string containing the height map file name (or "[none]" if not used). The size of this field is given by the name length plus one (for the terminating null character). | 
| byte | variable | Null terminating string containing the roughness map file name (or "[none]" if not used). The size of this field is given by the name length plus one (for the terminating null character). | 
| byte | variable | Null terminating string containing the metalness map file name (or "[none]" if not used). The size of this field is given by the name length plus one (for the terminating null character). | 

Material properties are defined with Physically-Based Rendering (PBR) in mind. When used with other illumination models (such as Blinn-Phong),
some conversion/adaption is required. A possible conversion to approximate Blinn-Phong might be as follows:

-# set ambient as a small percent of the albedo color (e.g., \f$ambient=albedo\times0.2\f$)
-# set specular as another percent of the albedo color (e.g., \f$specular=albedo\times0.4\f$)
-# set diffuse as (mostly) albedo (e.g., \f$diffuse=albedo\times0.6\f$)
-# set the shininess as \f$shininess=(1-\sqrt{roughness})\times128\f$
 <br><br>


***************************************
@subsection lightdata_subsec Light data
***************************************

This chunk describes a light source as an element of the scenegraph. Since light objects inherit from the node class, the first pieces
of information are the same as in the [node data](@ref nodedata_subsec).

| Type | Size | Description | 
| :--: | :--: | :---------- |
| byte | variable | Null terminating string containing the node name. The size of this field is given by the name length plus one (for the terminating null character). | 
| float | 64 bytes | 4x4 matrix for this node, as an array of float values. | 
| dword | 4 bytes | Number of child nodes. Following chunks that contain node information are the children of this node. | 
| byte | variable | Null terminating string containing the target node (or "[none]" if not used). The size of this field is given by the target name length plus one (for the terminating null character). | 
| byte | 1 byte | Light subtype (omni, directional, spot) as defined according to the enumeration available in class OvLight::SUBTYPE. | 
| float | 12 bytes | Light color (RGB) as a vector of three float components. | 
| float | 4 bytes | Light influence radius as a single float value. | 
| float | 12 bytes | Light direction as a vector of three float components. | 
| float | 4 bytes | Cutoff as a single float value. | 
| float | 4 bytes | Spot exponent as a single float value. | 
| byte | 1 byte | Shadow casting flag (0 = disable, 1 = enable). | 
| byte | 1 byte | Volumetric lighting flag (0 = disable, 1 = enable). | 
<br>


*************************************
@subsection meshdata_subsec Mesh data
*************************************

Mesh data contains all the information about a 3D object, including vertices, normals, faces, etc. Since mesh objects inherit from the node class, the first pieces
of information are the same as in the [node data](@ref nodedata_subsec).

| Type | Size | Description | 
| :--: | :--: | :---------- | 
| byte | variable | Null terminating string containing the node name. The size of this field is given by the name length plus one (for the terminating null character). |  
| float | 64 bytes | 4x4 matrix for this node, as an array of float values. | 
| dword | 4 bytes | Number of child nodes. Following chunks that contain node information are the children of this node. | 
| byte | variable | Null terminating string containing the target node (or "[none]" if not used). The size of this field is given by the target name length plus one (for the terminating null character). | 
| byte | 1 byte | Mesh subtype (standard, skinned, ...) as defined according to the enumeration available in class OvMesh::SUBTYPE. | 
| dword | 4 bytes | Number of vertices. | 
| dword | 4 bytes | Number of faces. | 
| byte | variable | Null terminating string containing the material name (or "[none]" if not used). The size of this field is given by the name length plus one (for the terminating null character). | 
| float | 4 bytes | Mesh radius size as a single float value. | 
| float | 12 bytes | Mesh bounding box minimum corner as a vector of three float components. | 
| float | 12 bytes | Mesh bounding box maximum corner as a vector of three float components. | 
| byte | 1 byte | Physics data included flag (0 = no, 1 = yes). See [physics properties](@ref physics_subsubsec)). | 
| byte | see next | If physics data is provided, a portion of data structured according to the [physics properties](@ref physics_subsubsec) section is found here. | 
| variable | variable | For each vertex, interleaved data structured as follows: xyz vertex coordinates as three float components, xyz normal as one single packed unsigned int (according to GL_INT_10_10_10_2_REV standard),<br> uv texture coords as two half float components, xyzw tangent vector, with sign in w, as packed unsigned int (according to GL_INT_10_10_10_2_REV standard). | 
| dword | variable | For each face, three unsigned int indexes referencing to the vertices of the previous field. | 
| variable | see next | If the mesh is of type skinned, a portion of data structured according to the [skinning properties](@ref skinning_subsubsec) section is found here. | 


****************************************************
@subsubsection physics_subsubsec Physics properties
****************************************************

When the physics data byte is not zero, an additional set of information is provided in the mesh chunk at the position specified in the previous section. The additional 
information is structured according to the OvMesh::ovMeshPhysics structure. In more detail:

| Type | Size | Description | 
| :--: | :--: | :---------- | 
| byte | 1 byte | Object type. | 
| byte | 1 byte | Hull type. | 
| byte | 1 byte | Continous collision detection flag (0 = no, 1 = yes). | 
| byte | 1 byte | Collide with rigid bodies flag (0 = no, 1 = yes). | 
| float | 12 bytes | Center of mass as a vector of three float components. | 
| float | 4 bytes | Mass. | 
| float | 4 bytes | Static friction. | 
| float | 4 bytes | Dynamic friction. | 
| float | 4 bytes | Bounciness. | 
| float | 4 bytes | Linear damping. | 
| float | 4 bytes | Angular damping. | 


*****************************************************
@subsubsection skinning_subsubsec Skinning properties
*****************************************************

When a mesh is of type skinned, an additional set of information is appended at the end of the standard mesh data to provide the number and name of used bones.

| Type | Size | Description | 
| :--: | :--: | :---------- | 
| float | 64 bytes | 4x4 mesh initial pose matrix, as an array of float values. | 
| dword | 4 bytes | Number of bones. Then, for each available bone, the next two fields are available, one after the other. | 
| byte | variable | Null terminating string containing the name of the 'Number of bones'-th bone. The size of this field is given by the name length plus one (for the terminating null character). | 
| float | 64 bytes | 4x4 bone initial pose matrix (already inverted). These two entries (previous and this one) are repeated 'Number of bones'-times. | 
| variable | variable | For each vertex, additional interleaved data structured as follows: first 16 bytes are 4 dword bone indexes, last 16 bytes are 4 float bone weights. | 
<br>


*************************************
@subsection bonedata_subsec Bone data
*************************************

The bone chunk contains information related to a specific bone used for vertex skinning. Since bone objects inherit from the node class, the first pieces
of information are the same as in the [node data](@ref nodedata_subsec). 

| Type | Size | Description | 
| :--: | :--: | :---------- | 
| byte | variable | Null terminating string containing the node name. The size of this field is given by the name length plus one (for the terminating null character). | 
| float | 64 bytes | 4x4 matrix for this node, as an array of float values. | 
| dword | 4 bytes | Number of child nodes. Following chunks that contain node information are the children of this node. | 
| byte | variable | Null terminating string containing the target node (or "[none]" if not used). The size of this field is given by the target name length plus one (for the terminating null character). | 
| float | 12 bytes | Bone bounding box minimum corner as a vector of three float components. | 
| float | 12 bytes | Bone bounding box maximum corner as a vector of three float components. | 
<br>

*/
