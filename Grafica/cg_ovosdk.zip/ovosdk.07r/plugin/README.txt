OVO export plugin for 3D Studio Max
-----------------------------------

Installation notes:

1) Copy the over3ds.dle file to the 'Plugins' directory within the 3D Studio Max installation 
directory, e.g.: C:\Program Files\Autodesk\3ds Max 2018\Plugins

2) Make sure you've the Visual Studio 2017 C/C++ Runtime redistributable installed. 
If not: https://support.microsoft.com/en-us/help/2977003/the-latest-supported-visual-c-downloads

You should now have a new 'OverVision Object (*.OVO)' entry under the 'save as type' drop-down
menu within the 'File -> Export -> Export...'  panel. 
