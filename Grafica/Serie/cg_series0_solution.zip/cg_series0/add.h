/**
 * @file		add.h
 * @brief	A simple class that does a+b
 *
 * @author	Achille Peternier (C) SUPSI [achille.peternier@supsi.ch]
 */
#pragma once



///////////////
// CLASS ADD //
///////////////

/** 
 * A simple class for summing two numbers.  
 */
class Add
{
//////////
public: //
//////////
   
	////////////////
   // Constructors:

   /**
    * Default constructor.
    */
   inline Add() : a(0), b(0)
   {}

   /**
    * Constructor with parameters.
    * @param a value of A
    * @param b value of B
    */
   inline Add(int a, int b)
   { 
      this->a = a; 
      this->b = b; 
   }


   ///////////
   // Get/set:

   /**
    * Set value of A.
    * @param a new value of A
    */
   inline void setA(int a) { this->a = a; }

   /**
    * Set value of B.
    * @param b new value of B
    */
   inline void setB(int b) { this->b = b; }

   /**
    * Get value of A.
    * @return value of A
    */
   inline int getA() { return a; }

   /**
    * Get value of B.
    * @return value of B
    */
   inline int getB() { return b; }

   // Main method:
   int doAPlusB();   


///////////
private: //
///////////

   // Components:
   int a, b;  
};
