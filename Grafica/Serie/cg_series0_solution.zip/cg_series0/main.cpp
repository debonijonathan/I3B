/**
 * @file		main.cpp
 * @brief	Visual Studio and CodeBlocks portability example (same code, two different projects)
 *
 * @author	Achille Peternier (C) SUPSI [achille.peternier@supsi.ch]
 */



//////////////
// #INCLUDE //
//////////////
   
   #include "add.h"   
   #include <iostream>      

   

//////////
// MAIN //
//////////

/**
 * Application entry point.
 * @param argc number of command-line arguments passed 
 * @param argv array containing up to argc passed arguments
 * @return error code (0 on success, error code otherwise)
 */
int main(int argc, char *argv[])
{
   // Credits:
   std::cout << "Visual Studio <--> CodeBlocks portable code, A. Peternier (C) SUPSI" << std::endl;
   std::cout << std::endl;   

   // Use class 'Add':
   Add add;
   add.setA(3);
   add.setB(-2);

   // Show result:
   std::cout << "   The sum of " << add.getA() << " plus " << add.getB() << " is " << add.doAPlusB() << "." << std::endl;

   // Done:
   return 0;
}
