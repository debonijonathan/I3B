/**
 * @file		add.cpp
 * @brief	A simple class that does a+b
 *
 * @author	Achille Peternier (C) SUPSI [achille.peternier@supsi.ch]
 */



//////////////
// #INCLUDE //
//////////////
   
   #include "add.h"



///////////////////////
// BODY OF CLASS ADD //
///////////////////////

/**
 * Main method adding B to A.  
 * @return the sum of a + b
 */
int Add::doAPlusB()
{
   return a + b;
}