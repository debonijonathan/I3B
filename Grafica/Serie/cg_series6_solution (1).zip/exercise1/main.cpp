/**
 * @file		main.cpp
 * @brief	Series 6, ex. 1
 *
 * @author	Achille Peternier (C) SUPSI [achille.peternier@supsi.ch]
 */



//////////////
// #INCLUDE //
//////////////

   // GLM:   
   #define GLM_FORCE_CTOR_INIT               // Force constructors to initialize to identity from v0.9.9
   #include <glm/glm.hpp>
   #include <glm/gtc/matrix_transform.hpp>
   #include <glm/gtc/type_ptr.hpp>

   // FreeGLUT:
   #include <GL/freeglut.h>

   // C/C++:
   #include <iostream>
   #include <stdio.h>
   #include <chrono>
   #include <thread>



/////////////
// #DEFINE //
/////////////

   // Quick define for the extension:
   #define GL_TEXTURE_MAX_ANISOTROPY_EXT        0x84FE
   #define GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT    0x84FF
   // See https://www.opengl.org/registry/specs/EXT/texture_filter_anisotropic.txt



/////////////
// GLOBALS //
/////////////

   // Rotation angles:
   float angleX = 0.0f, angleY = 0.0f;
   float distance = -45.0f;
   int windowId;

   // Matrices:
   glm::mat4 perspective;
   glm::mat4 ortho;

   // Texture:
   unsigned char *bitmap = nullptr;
   unsigned int texId = 0;
   float tiling = 1.0f;
   bool forceNewTexture = true;

   // Auto/manual flag:
   bool automatic = true;

   // Show/hide normals:
   bool showNormals = false;

   // Mipmaps?
   bool useMipmaps = false;

   // Anisotrophic?
   bool isAnisotropicSupported = false;
   bool anisotropic = false;
   int anisotropicLevel = 1;

   // Frame counter:
   int frames = 0;
   float fps = 0.0f;



/////////////
// METHODS //
/////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * On-the-fly generate an image to be used as texture (256x256 texels).
 */
void buildTexture()
{
   // Push settings:
   int viewport[4];
   glGetIntegerv(GL_VIEWPORT, viewport);

   // Clear the screen:
   glViewport(0, 0, 256, 256);
   glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


   //////////////////////////
   // Switch to 2D rendering:
   glm::mat4 ortho = glm::ortho(0.0f, 256.0f, 0.0f, 256.0f, -1.0f, 1.0f);

   // Set orthographic projection:
   glMatrixMode(GL_PROJECTION);
      glLoadMatrixf(glm::value_ptr(ortho));
   glMatrixMode(GL_MODELVIEW);
   glLoadMatrixf(glm::value_ptr(glm::mat4(1.0)));

   glDisable(GL_DEPTH_TEST);
   glDisable(GL_LIGHTING);

   // Pollock-like:
   for (int c = 0; c < 2000; c++)
   {
      glBegin(GL_POINTS + rand() % 4);
         int randV = rand() % 5;
         for (int d = 0; d < randV; d++)
         {
            glColor3ub(rand() % 256, rand() % 256, rand() % 256);
            glVertex2i(rand() % 256, rand() % 256);
         }
      glEnd();
   }

   // Copy back buffer to texture:
   if (forceNewTexture)
   {
      glReadPixels(0, 0, 256, 256, GL_RGB, GL_UNSIGNED_BYTE, bitmap);
      forceNewTexture = false;

#ifdef _DEBUG      
      // Show the content of the backbuffer for 3 secs:
      glutSwapBuffers();
      std::this_thread::sleep_for(std::chrono::milliseconds(3000));
#endif
   }

   // Update texture content:
   glBindTexture(GL_TEXTURE_2D, texId);

   // Set circular coordinates:
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   if (anisotropic && isAnisotropicSupported)
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, anisotropicLevel);
   else
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 1);

   // Set min/mag filters:
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   if (!useMipmaps)
   {
      // Without mipmapping:
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 256, 256, 0, GL_RGB, GL_UNSIGNED_BYTE, bitmap);
   }
   else
   {
      // Using mipmapping:
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
      gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB, 256, 256, GL_RGB, GL_UNSIGNED_BYTE, bitmap);
   }

   // Pop settings:
   glClearColor(1.0f, 0.6f, 0.1f, 1.0f);
   glViewport(0, 0, viewport[2], viewport[3]);
   glMatrixMode(GL_PROJECTION);
      glLoadMatrixf(glm::value_ptr(perspective));
   glMatrixMode(GL_MODELVIEW);

   glEnable(GL_DEPTH_TEST);
   glEnable(GL_LIGHTING);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Renders a cube given its edge size.
 * @param size cube edge dimension
 */
void displayCube(float edge)
{
   float size = edge / 2.0f;

   // Texture mapping just on the cube:
   glEnable(GL_TEXTURE_2D);

   // Back:
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(0.0f, 0.0f, -1.0f);
         glTexCoord2f(0.0f, 0.0f);
         glVertex3f(size, -size, -size);
         glTexCoord2f(tiling, 0.0f);
         glVertex3f(-size, -size, -size);
         glTexCoord2f(0.0f, tiling);
         glVertex3f(size, size, -size);
         glTexCoord2f(tiling, tiling);
         glVertex3f(-size, size, -size);
   glEnd();

   // Front:
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(0.0f, 0.0f, 1.0f);
         glTexCoord2f(0.0f, 0.0f);
         glVertex3f(-size, -size, size);
         glTexCoord2f(tiling, 0.0f);
         glVertex3f(size, -size, size);
         glTexCoord2f(0.0f, tiling);
         glVertex3f(-size, size, size);
         glTexCoord2f(tiling, tiling);
         glVertex3f(size, size, size);
   glEnd();

   // Left:
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(-1.0f, 0.0f, 0.0f);
         glTexCoord2f(0.0f, 0.0f);
         glVertex3f(-size, -size, -size);
         glTexCoord2f(tiling, 0.0f);
         glVertex3f(-size, -size, size);
         glTexCoord2f(0.0f, tiling);
         glVertex3f(-size, size, -size);
         glTexCoord2f(tiling, tiling);
         glVertex3f(-size, size, size);
   glEnd();

   // Right:
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(1.0f, 0.0f, 0.0f);
         glTexCoord2f(0.0f, 0.0f);
         glVertex3f(size, -size, -size);
         glTexCoord2f(tiling, 0.0f);
         glVertex3f(size, -size, size);
         glTexCoord2f(0.0f, tiling);
         glVertex3f(size, size, -size);
         glTexCoord2f(tiling, tiling);
         glVertex3f(size, size, size);
   glEnd();

   // Bottom:
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(0.0f, -1.0f, 0.0f);
         glTexCoord2f(0.0f, 0.0f);
         glVertex3f(size, -size, size);
         glTexCoord2f(tiling, 0.0f);
         glVertex3f(-size, -size, size);
         glTexCoord2f(0.0f, tiling);
         glVertex3f(size, -size, -size);
         glTexCoord2f(tiling, tiling);
         glVertex3f(-size, -size, -size);
   glEnd();

   // Top:
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(0.0f, 1.0f, 0.0f);
         glTexCoord2f(0.0f, 0.0f);
         glVertex3f(size, size, size);
         glTexCoord2f(tiling, 0.0f);
         glVertex3f(-size, size, size);
         glTexCoord2f(0.0f, tiling);
         glVertex3f(size, size, -size);
         glTexCoord2f(tiling, tiling);
         glVertex3f(-size, size, -size);
   glEnd();

   glDisable(GL_TEXTURE_2D);

   // Normals:
   if (showNormals)
   {
      float normalLength = 1.5f;
      glDisable(GL_LIGHTING);
         glBegin(GL_LINES);
            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(-size, 0.0f, 0.0f);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(-size * normalLength, 0.0f, 0.0f);

            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(size, 0.0f, 0.0f);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(size * normalLength, 0.0f, 0.0f);

            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(0.0f, -size, 0.0f);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(0.0f, -size * normalLength, 0.0f);

            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(0.0f, size, 0.0f);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(0.0f, size * normalLength, 0.0f);

            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(0.0f, 0.0f, -size);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(0.0f, 0.0f, -size * normalLength);

            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(0.0f, 0.0f, size);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(0.0f, 0.0f, size * normalLength);
         glEnd();
      glEnable(GL_LIGHTING);
   }
}



///////////////
// CALLBACKS //
///////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This is the main rendering routine automatically invoked by FreeGLUT.
 */
void displayCallback()
{
   // Clear the screen:
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


   //////
   // 3D:

   // Set perpsective matrix:
   glMatrixMode(GL_PROJECTION);
      glLoadMatrixf(glm::value_ptr(perspective));
   glMatrixMode(GL_MODELVIEW);

   // Set a matrix to move our triangle:
   glm::mat4 translation = glm::translate(glm::mat4(), glm::vec3(0.0f, 0.0f, distance));
   glm::mat4 rotation = glm::rotate(glm::mat4(), glm::radians(angleX), glm::vec3(1.0f, 0.0f, 0.0f));
   rotation = glm::rotate(rotation, glm::radians(angleY), glm::vec3(0.0f, 1.0f, 0.0f));

   glm::mat4 f = translation * rotation;

   // Set model matrix as current OpenGL matrix:
   glLoadMatrixf(glm::value_ptr(f));

   // Draw the cube:
   displayCube(20);


   //////
   // 2D:

   // Set orthographic projection:
   glMatrixMode(GL_PROJECTION);
      glLoadMatrixf(glm::value_ptr(ortho));
   glMatrixMode(GL_MODELVIEW);
   glLoadMatrixf(glm::value_ptr(glm::mat4(1.0)));

   // Disable lighting before rendering 2D text:
   glDisable(GL_LIGHTING);

   // Write some text:
   char text[64];
   if (useMipmaps)
      strcpy(text, "[m] Using mipmapping");
   else
      strcpy(text, "[m] Without mipmapping");
   glColor3f(1.0f, 1.0f, 1.0f);
   glRasterPos2f(1.0f, 8.0f);
   glutBitmapString(GLUT_BITMAP_8_BY_13, (unsigned char *) text);

   if (isAnisotropicSupported)
   {
      if (anisotropic)
         strcpy(text, "[a] Using anistropic filtering");
      else
         strcpy(text, "[a] Without anisotropic filtering");
   }
   else
      strcpy(text, "[Anisotropic filtering not supported]");
   glColor3f(1.0f, 1.0f, 1.0f);
   glRasterPos2f(1.0f, 22.0f);
   glutBitmapString(GLUT_BITMAP_8_BY_13, (unsigned char *) text);

   sprintf(text, "FPS: %.1f", fps);
   glRasterPos2f(1.0f, 36.0f);
   glutBitmapString(GLUT_BITMAP_8_BY_13, (unsigned char *) text);

   // Redo ligting:
   glEnable(GL_LIGHTING);

   // Swap this context's buffer:
   glutSwapBuffers();

   // Update coords:
   if (automatic)
   {
      angleX += 0.2f;
      angleY += 0.4f;

      // Force rendering refresh:
      glutPostWindowRedisplay(windowId);
   }

   // Inc. frames:
   frames++;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This callback is invoked each time the window gets resized (and once also when created).
 * @param width new window width
 * @param height new window height
 */
void reshapeCallback(int width, int height)
{
   std::cout << "[reshape func invoked]" << std::endl;

   // Update viewport size:
   glViewport(0, 0, width, height);

   // Update matrices:
   perspective = glm::perspective(glm::radians(45.0f), (float) width / (float) height, 1.0f, 100.0f);
   ortho = glm::ortho(0.0f, (float) width, 0.0f, (float) height, -1.0f, 1.0f);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This callback is invoked each time a standard keyboard key is pressed.
 * @param key key pressed id
 * @param mouseX mouse X coordinate
 * @param mouseY mouse Y coordinate
 */
void keyboardCallback(unsigned char key, int mouseX, int mouseY)
{
   std::cout << "[std key pressed]" << std::endl;

   switch (key)
   {
      case ' ':
         automatic = !automatic;
         break;

      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
         tiling = (float) ((key - '1') + 1);
         break;

      case 'n':
         showNormals = !showNormals;
         break;

      case 'a':
         anisotropic = !anisotropic;
         buildTexture();
         break;

      case 'm':
         useMipmaps = !useMipmaps;
         buildTexture();
         break;

      case 't':
         forceNewTexture = true;
         buildTexture();
         break;

      case 'r':
         {
            glm::vec4 color((rand() % 100) / 100.0f,
                            (rand() % 100) / 100.0f,
                            (rand() % 100) / 100.0f,
                            1.0f);
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, glm::value_ptr(color));
            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, glm::value_ptr(color));
         }
         break;
   }

   // Force rendering refresh:
   glutPostWindowRedisplay(windowId);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This callback is invoked each time a special keyboard key is pressed.
 * @param key key pressed id
 * @param mouseX mouse X coordinate
 * @param mouseY mouse Y coordinate
 */
void specialCallback(int key, int mouseX, int mouseY)
{
   std::cout << "[key pressed]" << std::endl;

   // Automatic-mode, not needed:
   if (automatic)
      return;

   // Change box rotation:
   const float speed = 1.0f;
   switch (key)
   {
      case GLUT_KEY_UP:
         angleX -= speed;
         break;

      case GLUT_KEY_DOWN:
         angleX += speed;
         break;

      case GLUT_KEY_LEFT:
         angleY -= speed;
         break;

      case GLUT_KEY_RIGHT:
         angleY += speed;
         break;
   }

   // Force rendering refresh:
   glutPostWindowRedisplay(windowId);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This callback is invoked each 3 seconds.
 * @param value passepartout value
 */
void timerCallback(int value)
{
   fps = frames / 1.0f;
   frames = 0;

   // Register the next update:
   glutTimerFunc(1000, timerCallback, 0);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This callback is invoked when the mainloop is left and before the context is released.  
 */
void closeCallback()
{
   std::cout << "[close func invoked]" << std::endl;

   // Release OpenGL resources while the context is still available:
   glDeleteTextures(1, &texId);
}



//////////
// MAIN //
//////////

/**
 * Application entry point.
 * @param argc number of command-line arguments passed
 * @param argv array containing up to argc passed arguments
 * @return error code (0 on success, error code otherwise)
 */
int main(int argc, char *argv[])
{
   // Credits:
   std::cout << "3D spinning cube + texturing, A. Peternier (C) SUPSI" << std::endl;
   std::cout << std::endl;

   // Init context:
   glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
   glutInitWindowPosition(100, 100);

   // FreeGLUT can parse command-line params, in case:
   glutInit(&argc, argv);

   // Set some optional flags:
   glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);

   // Create the window with a specific title:
   windowId = glutCreateWindow("3D spinning cube + texturing");

   // Check for anistropic filtering extension:   
   if (strstr((const char *)glGetString(GL_EXTENSIONS), "GL_EXT_texture_filter_anisotropic"))
   {
      std::cout << "   Anisotropic filtering supported" << std::endl;
      isAnisotropicSupported = true;
      glGetIntegerv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &anisotropicLevel);
      std::cout << "   Anisotropic filtering max. level: " << anisotropicLevel << std::endl;
   }
   else
   {
      std::cout << "   Anisotropic filtering not supported" << std::endl;
   }

   // Set callback functions:
   glutDisplayFunc(displayCallback);
   glutReshapeFunc(reshapeCallback);
   glutKeyboardFunc(keyboardCallback);
   glutSpecialFunc(specialCallback);
   glutCloseFunc(closeCallback);   
   glutTimerFunc(3000, timerCallback, 0);

   // Build texture:
   glGenTextures(1, &texId);
   bitmap = new unsigned char[256 * 256 * 3];
   buildTexture();

   // Global OpenGL settings:
   glClearColor(1.0f, 0.6f, 0.1f, 1.0f);
   glEnable(GL_DEPTH_TEST);
   glEnable(GL_LIGHTING);
   glEnable(GL_LIGHT0);

   // Enter the main FreeGLUT processing loop:
   glutMainLoop();

   // Release resources:   
   delete [] bitmap;

   // Done:
   std::cout << "[application terminated]" << std::endl;
   return 0;
}
