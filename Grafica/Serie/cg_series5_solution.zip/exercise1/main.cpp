/**
 * @file		main.cpp
 * @brief	Series 5, ex. 1
 *
 * @author	Achille Peternier (C) SUPSI [achille.peternier@supsi.ch]
 */



//////////////
// #INCLUDE //
//////////////

   // GLM:   
   #define GLM_FORCE_CTOR_INIT               // Force constructors to initialize to identity from v0.9.9
   #include <glm/glm.hpp>
   #include <glm/gtc/matrix_transform.hpp>
   #include <glm/gtc/type_ptr.hpp>
   
   // FreeGLUT:   
   #include <GL/freeglut.h>

   // C/C++:
   #include <iostream>      
   


/////////////
// GLOBALS //
/////////////

   // Flags:
   bool wireframe = false;
   bool culling = false;

   // Rotation angles:
   float angleX = 0.0f, angleY = 0.0f;
   float distance = -45.0f;
   int windowId;

   // Auto/manual flag:
   bool automatic = true;

   // Show/hide normals:
   bool showNormals = false;

   // Frame counter:
   int frames = 0;



//////////
// CUBE //
//////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Renders a cube given its edge size.
 * @param size cube edge dimension
 */
void displayCube(float edge)
{
   float size = edge / 2.0f;
   
   // Back:
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(0.0f, 0.0f, -1.0f);
         glVertex3f(size, -size, -size);
         glVertex3f(-size, -size, -size);
         glVertex3f(size, size, -size);
         glVertex3f(-size, size, -size);         
   glEnd();   
      
   // Front:	      
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(0.0f, 0.0f, 1.0f);
         glVertex3f(-size, -size, size);
         glVertex3f(size, -size, size);
         glVertex3f(-size, size, size);
         glVertex3f(size, size, size);
   glEnd();      
   
   // Left:	      
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(-1.0f, 0.0f, 0.0f);
         glVertex3f(-size, size, -size);
         glVertex3f(-size, -size, -size);
         glVertex3f(-size, size, size);
         glVertex3f(-size, -size, size);
   glEnd();         
   
   // Right:	      
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(1.0f, 0.0f, 0.0f);
         glVertex3f(size, -size, -size);
         glVertex3f(size, size, -size);
         glVertex3f(size, -size, size);
         glVertex3f(size, size, size);
   glEnd();     

   // Bottom:	      
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(0.0f, -1.0f, 0.0f);
         glVertex3f(-size, -size, -size);
         glVertex3f(size, -size, -size);
         glVertex3f(-size, -size, size);
         glVertex3f(size, -size, size);
   glEnd();         
   
   // Top:	      
   glBegin(GL_TRIANGLE_STRIP);
      glNormal3f(0.0f, 1.0f, 0.0f);
         glVertex3f(size, size, -size);
         glVertex3f(-size, size, -size);
         glVertex3f(size, size, size);
         glVertex3f(-size, size, size);
   glEnd();

   // Normals:
   if (showNormals)
   {
      float normalLength = 1.5f;
      glDisable(GL_LIGHTING);
         glBegin(GL_LINES);
            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(-size, 0.0f, 0.0f);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(-size * normalLength, 0.0f, 0.0f);        

            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(size, 0.0f, 0.0f);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(size * normalLength, 0.0f, 0.0f);        

            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(0.0f, -size, 0.0f);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(0.0f, -size * normalLength, 0.0f);        

            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(0.0f, size, 0.0f);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(0.0f, size * normalLength, 0.0f);        

            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(0.0f, 0.0f, -size);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(0.0f, 0.0f, -size * normalLength);        

            glColor3f(0.5f, 0.5f, 1.0f);
               glVertex3f(0.0f, 0.0f, size);
            glColor3f(0.0f, 0.0f, 1.0f);
               glVertex3f(0.0f, 0.0f, size * normalLength);        
         glEnd();
      glEnable(GL_LIGHTING);
   }
}



///////////////
// CALLBACKS //
///////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This is the main rendering routine automatically invoked by FreeGLUT.
 */
void displayCallback()
{
   // Clear the screen:            
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   // Set a matrix to move our triangle:    
   glm::mat4 translation = glm::translate(glm::mat4(), glm::vec3(0.0f, 0.0f, distance));
   glm::mat4 rotation = glm::rotate(glm::mat4(), glm::radians(angleX), glm::vec3(1.0f, 0.0f, 0.0f));
   rotation = glm::rotate(rotation, glm::radians(angleY), glm::vec3(0.0f, 1.0f, 0.0f));
   
   glm::mat4 f = translation * rotation;

   // Set model matrix as current OpenGL matrix:
   glLoadMatrixf(glm::value_ptr(f));

   // Draw the cube:
   displayCube(20);
   
   // Swap this context's buffer:     
   glutSwapBuffers();            
   
   // Update coords:
   if (automatic)
   {
      angleX += 0.2f;
      angleY += 0.4f;

      // Force rendering refresh:
      glutPostWindowRedisplay(windowId);
   }

   // Inc. frames:
   frames++;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This callback is invoked each time the window gets resized (and once also when created).
 * @param width new window width
 * @param height new window height
 */
void reshapeCallback(int width, int height)
{
   std::cout << "[reshape func invoked]" << std::endl;

   glViewport(0, 0, width, height);
   glMatrixMode(GL_PROJECTION);
   glm::mat4 projection = glm::perspective(glm::radians(45.0f), (float) width / (float) height, 1.0f, 100.0f);
   glLoadMatrixf(glm::value_ptr(projection));
   glMatrixMode(GL_MODELVIEW);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This callback is invoked each time a standard keyboard key is pressed.
 * @param key key pressed id
 * @param mouseX mouse X coordinate
 * @param mouseY mouse Y coordinate 
 */
void keyboardCallback(unsigned char key, int mouseX, int mouseY)
{
   std::cout << "[std key pressed]" << std::endl;
   
   switch (key)
   {      
      case ' ':
         automatic = !automatic;
         break;

      case 'c':
         culling = !culling;
         if (culling)
            glEnable(GL_CULL_FACE);
         else
            glDisable(GL_CULL_FACE);
         break;

      case 'n':
         showNormals = !showNormals;
         break;

      case 'w':
         wireframe = !wireframe;
         if (wireframe)
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
         else
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
         break;

      case 'r':
         {
            glm::vec4 color((rand() % 100) / 100.0f, 
                            (rand() % 100) / 100.0f, 
                            (rand() % 100) / 100.0f, 
                            1.0f);
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, glm::value_ptr(color));
            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, glm::value_ptr(color));
         }
         break;
   }

   // Force rendering refresh:
   glutPostWindowRedisplay(windowId);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This callback is invoked each time a special keyboard key is pressed.
 * @param key key pressed id
 * @param mouseX mouse X coordinate
 * @param mouseY mouse Y coordinate 
 */
void specialCallback(int key, int mouseX, int mouseY)
{
   std::cout << "[key pressed]" << std::endl;

   // Automatic-mode, not needed:
   if (automatic)
      return;

   // Change box rotation:
   const float speed = 1.0f;
   switch (key)
   {
      case GLUT_KEY_UP: 
         angleX -= speed;
         break;

      case GLUT_KEY_DOWN:
         angleX += speed;
         break;

      case GLUT_KEY_LEFT:
         angleY -= speed;
         break;

      case GLUT_KEY_RIGHT:
         angleY += speed;
         break;
   }

   // Force rendering refresh:
   glutPostWindowRedisplay(windowId);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * This callback is invoked each 3 seconds.
 * @param value passepartout value
 */
void timerCallback(int value)
{
   float fps = frames / 3.0f;
   frames = 0;
   std::cout << "fps: " << fps << std::endl;

   // Register the next update:
   glutTimerFunc(3000, timerCallback, 0);
}



//////////
// MAIN //
//////////

/**
 * Application entry point.
 * @param argc number of command-line arguments passed 
 * @param argv array containing up to argc passed arguments
 * @return error code (0 on success, error code otherwise)
 */
int main(int argc, char *argv[])
{
   // Credits:
   std::cout << "3D spinning cube + lighting, A. Peternier (C) SUPSI" << std::endl;
   std::cout << std::endl;   

   // Init context:
   glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
   glutInitWindowPosition(100, 100);
   
   // FreeGLUT can parse command-line params, in case:
   glutInit(&argc, argv);   

   // Set some optional flags:
   glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);   
   
   // Create the window with a specific title:   
   windowId = glutCreateWindow("3D spinning cube + lighting");   
   
   // Set callback functions:
   glutDisplayFunc(displayCallback);  
   glutReshapeFunc(reshapeCallback);   
   glutKeyboardFunc(keyboardCallback);
   glutSpecialFunc(specialCallback);   
   glutTimerFunc(3000, timerCallback, 0);

   // Global OpenGL settings:
   glClearColor(1.0f, 0.6f, 0.1f, 1.0f);
   glEnable(GL_DEPTH_TEST);
   glEnable(GL_LIGHTING);
   glEnable(GL_LIGHT0);
   
   // Enter the main FreeGLUT processing loop:     
   glutMainLoop();

   // Done:
   std::cout << "[application terminated]" << std::endl;
   return 0;
}