/**
 * @file		main.cpp
 * @brief	A triangle passes through the whole rasterization pipeline
 *
 * @author	Achille Peternier (C) SUPSI [achille.peternier@supsi.ch]
 */



//////////////
// #INCLUDE //
//////////////

   // 3D math:   
   #include <glm/glm.hpp>                  // Add path to required header files under "Project->Properties->C/C++->General->Additional Include Directories"
   #include <glm/gtc/matrix_transform.hpp> // Deprecated OpenGL functions

   // C++ libs:
   #include <iostream>



/////////////
// #DEFINE //
/////////////

   // Macro for quickly printing a vector4 to console:
   #define VEC2STR(v) "[" << v.x << "\t" << v.y << "\t" << v.z << "\t" << v.w << "] --> (" << v.x/v.w << ", " << v.y/v.w << ", " << v.z/v.w << ")"

   // Macro for printing a Matrix4 to console:
   #define MAT2STR(m) "\t" << m[0][0] << "\t" << m[0][1] << "\t" << m[0][2] << "\t" << m[0][3] << std::endl \
                   << "\t" << m[1][0] << "\t" << m[1][1] << "\t" << m[1][2] << "\t" << m[1][3] << std::endl \
                   << "\t" << m[2][0] << "\t" << m[2][1] << "\t" << m[2][2] << "\t" << m[2][3] << std::endl \
                   << "\t" << m[3][0] << "\t" << m[3][1] << "\t" << m[3][2] << "\t" << m[3][3]



//////////
// MAIN //
//////////

/**
 * Application entry point.
 * @param argc number of command-line arguments passed
 * @param argv array containing up to argc passed arguments
 * @return error code (0 on success, error code otherwise)
 */
int main(int argc, char *argv[])
{
   // Credits:
   std::cout << "A triangle through the pipeline, A. Peternier (C) SUPSI" << std::endl;
   std::cout << std::endl;
   std::cout.precision(2);
   std::cout << std::fixed;

   // Define matrices (the lazy-way using glm deprecated functions instead of plain matrices...):
   glm::mat4 t1 = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f));
   glm::mat4 t2 = glm::rotate(glm::mat4(1.0f), glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
   glm::mat4 t3 = glm::translate(glm::mat4(1.0f), glm::vec3(10.0f, 0.0f, 0.0f));
   glm::mat4 perspective = glm::perspective(glm::radians(45.0f), 1.0f, 1.0f, 100.0f);

   // Define vertices (using homogeneous coords):
   glm::vec4 vertexIn[3];
   vertexIn[0] = glm::vec4(-15.0f, 0.0f, -50.0f, 1.0f);
   vertexIn[1] = glm::vec4(15.0, 0.0f, -50.0f, 1.0f);
   vertexIn[2] = glm::vec4(0.0, 15.0f, -50.0f, 1.0f);


   ///////////////////////////
   // Case 1: just perspective
   std::cout << "1) Perspective only" << std::endl;

   glm::mat4 f = perspective;
   std::cout << "   f = " << MAT2STR(f) << std::endl;

   // Compute clip-space coords:
   std::cout << std::endl;
   glm::vec4 vertexOut[3];
   for (int c = 0; c < 3; c++)
   {
      vertexOut[c] = f * vertexIn[c];
      std::cout << "   " << c << ") " << VEC2STR(vertexOut[c]) << std::endl;
   }


   //////////////////
   // Case 2: scaling
   std::cout << std::endl << "2) Scaling" << std::endl;

   f = perspective * t1;
   std::cout << "   f = " << MAT2STR(f) << std::endl;

   // Compute clip-space coords:
   std::cout << std::endl;
   for (int c = 0; c < 3; c++)
   {
      vertexOut[c] = f * vertexIn[c];
      std::cout << "   " << c << ") " << VEC2STR(vertexOut[c]) << std::endl;
   }


   ///////////////////
   // Case 3: rotation
   std::cout << std::endl << "3) Rotation" << std::endl;

   f = perspective * t2;
   std::cout << "   f = " << MAT2STR(f) << std::endl;

   // Compute clip-space coords:
   std::cout << std::endl;
   for (int c = 0; c < 3; c++)
   {
      vertexOut[c] = f * vertexIn[c];
      std::cout << "   " << c << ") " << VEC2STR(vertexOut[c]) << std::endl;
   }


   //////////////////////
   // Case 4: translation
   std::cout << std::endl << "4) Translation" << std::endl;

   f = perspective * t3;
   std::cout << "   f = " << MAT2STR(f) << std::endl;

   // Compute clip-space coords:
   std::cout << std::endl;
   for (int c = 0; c < 3; c++)
   {
      vertexOut[c] = f * vertexIn[c];
      std::cout << "   " << c << ") " << VEC2STR(vertexOut[c]) << std::endl;
   }


   /////////////////
   // Case 5: all in
   std::cout << std::endl << "5) All-in" << std::endl;

   f = perspective * t3 * t2 * t1;
   std::cout << "   f = " << MAT2STR(f) << std::endl;

   // Compute clip-space coords:
   std::cout << std::endl;
   for (int c = 0; c < 3; c++)
   {
      vertexOut[c] = f * vertexIn[c];
      std::cout << "   " << c << ") " << VEC2STR(vertexOut[c]) << std::endl;
   }

   // Done:
   std::cout << std::endl;
   return 0;
}
