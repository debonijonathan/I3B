/**
 * @file		customMath.cpp
 * @brief	Homemade 3D vector and matrix class example
 * 
 * @author	Achille Peternier (C) SUPSI [achille.peternier@supsi.ch]
 */



//////////////
// #INCLUDE //
//////////////

   // 3D math:   
   #include "vector3.h"
   #include "matrix3.h"

   // C++ libs:
   #include <iostream>



/////////////
// #DEFINE //
/////////////

   // Macro for quickly printing a vector to console:
   #define VEC2STR(v) "[" << v.x << " " << v.y << " " << v.z << "]"   

   // Macro for printing a Matrix3 to console:
   #define MAT2STR(m) "\t|\t" << m[0][0] << "\t" << m[0][1] << "\t" << m[0][2] << "\t|" << std::endl \
                   << "\t|\t" << m[1][0] << "\t" << m[1][1] << "\t" << m[1][2] << "\t|" << std::endl \
                   << "\t|\t" << m[2][0] << "\t" << m[2][1] << "\t" << m[2][2] << "\t|"



//////////
// MAIN //
//////////

/**
 * Application entry point.
 * @param argc number of command-line arguments passed 
 * @param argv array containing up to argc passed arguments
 * @return error code (0 on success, error code otherwise)
 */
int main(int argc, char *argv[])
{   
   // Credits:
   std::cout << "Homemade 3D math classes, A. Peternier (C) SUPSI" << std::endl;
   std::cout << std::endl;      

   // Series 2, ex. 1, b:    
   {
      Matrix3 M(0.5f, -1.0f, -2.0f,
                1.0f,  0.5f, -1.0f,
                2.0f,  1.0f, -0.5f);

      M.transpose();
      M.transpose();
      M.transpose();      
      std::cout << "   b) " << MAT2STR(M.m) << std::endl;  
   }

   // Series 2, ex. 1, c: 
   {
      Vector3 a(1, 1, 0);
      Matrix3 M(1.0f, 0.0f, 30.0f,
                0.0f, 1.0f, 15.0f,
                0.0f, 0.0f, 1.0f);
   
      Vector3 r = M * a;
      std::cout << "   c) " << VEC2STR(r) << std::endl;   
   }

   // Series 2, ex. 1, d:
   {
      Matrix3 M1( 1.0f, -1.0f, 0.0f,
                 -1.0f,  1.0f, 0.0f,
                  0.0f,  0.0f, 1.0f);
      Matrix3 M2(1.0f, 0.0f, 30.0f,
                 0.0f, 1.0f, 15.0f,
                 0.0f, 0.0f, 1.0f);
   
      M1.transpose();
      Matrix3 R = M1 * M2; 
      std::cout << "   d) " << MAT2STR(R.m) << std::endl;
   }   

   // Done:
   std::cout << std::endl;   
   return 0;
}