/**
 * @file		matrix3.h
 * @brief	3D matrix class with basic functionalities
 * 
 * @author	Achille Peternier (C) SUPSI [achille.peternier@supsi.ch]
 */
#pragma once



//////////////
// #INCLUDE //
//////////////

   #include "vector3.h"



///////////////////
// CLASS MATRIX3 //
///////////////////

/** 
 * 3x3 matrix class.  
 */
class Matrix3
{
//////////
public: //
//////////

   // Components:
   union 
	{
		float d[9];			///< Matrix data accessible as a linear array of float
		float m[3][3];		///< Matrix data accessible as a bidimensional array of float
		
		/**
		 * Accessing components as direct independent values.
		 */
		struct
		{
			float _11;			///< Matrix [0][0]
			float _12;			///< Matrix [0][1]			
			float _13;			///< Matrix [0][2] 		   
			
			float _21;			///< Matrix [1][0]
			float _22;			///< Matrix [1][1]			
			float _23;			///< Matrix [1][2] 			
			
			float _31;			///< Matrix [2][0]
			float _32;			///< Matrix [2][1]			
			float _33;			///< Matrix [2][2] 			
		};		
	};
	

   ////////////////
	// Constructors:   
	Matrix3() : _11(1.0f), _12(0.0f), _13(0.0f),
					_21(0.0f), _22(1.0f), _23(0.0f),
					_31(0.0f), _32(0.0f), _33(1.0f)					
	{}

   Matrix3(float _11, float _12, float _13,
		     float _21, float _22, float _23,
		     float _31, float _32, float _33)
	{     
		this->_11 = _11;	this->_21 = _21;	this->_31 = _31;
		this->_12 = _12;	this->_22 = _22;	this->_32 = _32;
		this->_13 = _13;	this->_23 = _23;	this->_33 = _33;		
	}

	
   /////////////
   // Operators:    
   Vector3 operator*(const Vector3 &v) const
	{		
		return Vector3(_11*v.x + _12*v.y + _13*v.z,
							_21*v.x + _22*v.y + _23*v.z,
							_31*v.x + _32*v.y + _33*v.z);	
	}
   
	Matrix3 operator*(const Matrix3 &matrix)
	{	      
      return Matrix3(_11 * matrix._11 + _12 * matrix._21 + _13 * matrix._31,
						   _11 * matrix._12 + _12 * matrix._22 + _13 * matrix._32,
   						_11 * matrix._13 + _12 * matrix._23 + _13 * matrix._33,							  

					      _21 * matrix._11 + _22 * matrix._21 + _23 * matrix._31,
					      _21 * matrix._12 + _22 * matrix._22 + _23 * matrix._32,
					      _21 * matrix._13 + _22 * matrix._23 + _23 * matrix._33,					        

					      _31 * matrix._11 + _32 * matrix._21 + _33 * matrix._31,
					      _31 * matrix._12 + _32 * matrix._22 + _33 * matrix._32,
					      _31 * matrix._13 + _32 * matrix._23 + _33 * matrix._33);      
   }	

	
   //////////////////
   // Extra features:
   void transpose()
	{
		Matrix3 t(*this);
	 /*_11 = t._11;*/ _12 = t._21;   _13 = t._31; 
		_21 = t._12; /*_22 = t._22;*/ _23 = t._32; 
		_31 = t._13;   _32 = t._23; /*_33 = t._33;*/ 
	}	
};
