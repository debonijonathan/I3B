/**
 * @file		vector3.h
 * @brief	3D vector class with basic functionalities
 *
 * @author	Achille Peternier (C) SUPSI [achille.peternier@supsi.ch]
 */
#pragma once



//////////////
// #INCLUDE //
//////////////

   #define _USE_MATH_DEFINES // <-- required on Windows for M_PI
   #include <math.h>



///////////////////
// CLASS VECTOR3 //
///////////////////

/**
 * 3D vector class.
 */
class Vector3
{
//////////
public: //
//////////

   // Components:
   float x, y, z;


   //////////////
	// Const/dest:

   /**
    * Default constructor.
    */
	Vector3() : x(0.0f), y(0.0f), z(0.0f)
   {}

   /**
    * Constructor with (float) parameters.
    * @param x X component
    * @param y Y component
    * @param z Z component
    */
	Vector3(float x, float y, float z)
   {
      this->x = x;
      this->y = y;
      this->z = z;
   }

   /**
    * Constructor with (int) parameters.
    * @param x X component
    * @param y Y component
    * @param z Z component
    */
   Vector3(int x, int y, int z)
   {
      this->x = (float) x;
      this->y = (float) y;
      this->z = (float) z;
   }


   /////////////
   // Operators:
	Vector3 operator-() const
   { return Vector3(-x,-y,-z); }

   Vector3 operator+(const Vector3 &v) const
   { return Vector3(this->x+v.x, this->y+v.y, this->z+v.z); }

	Vector3 operator-(const Vector3 &v) const
	{ return Vector3(this->x-v.x, this->y-v.y, this->z-v.z); }

	Vector3 operator*(const Vector3 &v) const
	{ return Vector3(this->x*v.x, this->y*v.y, this->z*v.z); }


   //////////////////
   // Extra features:

   // Dot product:
	float operator%(const Vector3 &v) const
	{ return (x*v.x + y*v.y + z*v.z); }

	// Cross product:
	Vector3 operator^(const Vector3 &v) const
	{ return Vector3(this->y*v.z - this->z*v.y, this->z*v.x - this->x*v.z, this->x*v.y - this->y*v.x); }

   /**
    * Get vector length.
    * @return vector length
    */
   float length()
   { return sqrtf(x*x + y*y + z*z); }

   /**
    * Apply normalization to this vector.
    */
	void normalize()
	{
		float _length = length();
		if (_length == 0.0f)
			_length = 1.0f;
		x/=_length;
		y/=_length;
		z/=_length;
	}
};
