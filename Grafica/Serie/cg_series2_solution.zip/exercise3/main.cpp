/**
 * @file		main.cpp
 * @brief	GLM crash test
 *
 * @author	Achille Peternier (C) SUPSI [achille.peternier@supsi.ch]
 */



//////////////
// #INCLUDE //
//////////////

   // 3D math:   
   #include <glm/glm.hpp>           // Add path to required header files under "Project->Properties->C/C++->General->Additional Include Directories"
   #include <glm/gtc/constants.hpp> // Required for constants such as Greek PI

   // C++ libs:
   #include <iostream>



/////////////
// #DEFINE //
/////////////

   // Macro for quickly printing a vector to console:
   #define VEC2STR(v) "[" << v.x << " " << v.y << " " << v.z << "]"
   
   // Macro for printing a Matrix3 to console:
   #define MAT2STR(m) "\t|\t" << m[0][0] << "\t" << m[0][1] << "\t" << m[0][2] << "\t|" << std::endl \
                   << "\t|\t" << m[1][0] << "\t" << m[1][1] << "\t" << m[1][2] << "\t|" << std::endl \
                   << "\t|\t" << m[2][0] << "\t" << m[2][1] << "\t" << m[2][2] << "\t|"



//////////
// MAIN //
//////////

/**
 * Application entry point.
 * @param argc number of command-line arguments passed 
 * @param argv array containing up to argc passed arguments
 * @return error code (0 on success, error code otherwise)
 */
int main(int argc, char *argv[])
{
   // Credits:
   std::cout << "GLM 3D math classes, A. Peternier (C) SUPSI" << std::endl;
   std::cout << std::endl;      
   
   // Series 2, ex. 1, b:    
   {
      glm::mat3x3 M(0.5f,   1.0f,  2.0f,
                    -1.0f,  0.5f,  1.0f,
                    -2.0f, -1.0f, -0.5f);

      M = glm::transpose(M);
      M = glm::transpose(M);
      M = glm::transpose(M);      
      std::cout << "   b) " << MAT2STR(M) << std::endl;  
   }

   // Series 2, ex. 1, c: 
   {
      glm::vec3 a(1, 1, 0);
      glm::mat3x3 M(1.0f,  0.0f,  0.0f,
                    0.0f,  1.0f,  0.0f,
                    30.0f, 15.0f, 1.0f);

      glm::vec3 r = M * a; 
      std::cout << "   c) " << VEC2STR(r) << std::endl;  
   }

   // Series 2, ex. 1, d:
   {
      glm::mat3x3 M1( 1.0f, -1.0f, 0.0f,
                     -1.0f,  1.0f, 0.0f,
                      0.0f,  0.0f, 1.0f);           
      glm::mat3x3 M2(1.0f,  0.0f,  0.0f,
                     0.0f,  1.0f,  0.0f,
                     30.0f, 15.0f, 1.0f);

      M1 = glm::transpose(M1);   
      glm::mat3x3 R = M1 * M2; 
      std::cout << "   d) " << MAT2STR(R) << std::endl;
   }   

   // Done:
   std::cout << std::endl;      
   return 0;
}