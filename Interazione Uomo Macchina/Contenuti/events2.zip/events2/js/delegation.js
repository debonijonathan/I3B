;
(() => {
  "use strict";
  const handler = (e) => {
    let target = e.target;
    if(target.tagName.toLowerCase() !== 'button'){
      return;
    }
    console.log('ciao', target.getAttribute('data-content'));
  };
  let table = document.querySelector('table');
  table.addEventListener('click', handler, false);

})();