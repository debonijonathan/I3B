;(() => {
  "use strict";

  const handler = () => {
    console.log('%c premuto! ', 'background:orange;color:white');
  };

  let btn = document.querySelector('button');

  btn.addEventListener('click', handler, false);
  
})();