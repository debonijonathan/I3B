const AnotherModule = {
  'answer': 42
};

export { AnotherModule };