const myModule = {
  hello: 'World!'
};

export { myModule };