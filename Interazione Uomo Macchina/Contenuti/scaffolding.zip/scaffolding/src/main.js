import { myModule } from './mymodule';
import { HelloButton } from './button'
console.log('main file ok');

console.log('module loaded:', myModule);