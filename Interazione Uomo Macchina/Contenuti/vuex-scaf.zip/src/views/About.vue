<template>
  <div class="about">
    <h1>This is an about page</h1>
  </div>
</template>
<style scoped lang="scss">
h1{
  color:#ddd;
}

</style>
