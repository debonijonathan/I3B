<template>
  <div class="home">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
      <button @click="increment">Click to increment</button>
      <button @click="decrement">Click to decrement</button>
    <div>
      <div class="counter">
        counter value = {{count}}
      </div>
      <div class="counter">
        double value = {{doubleCount}}
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from "@/components/HelloWorld.vue";
import { mapState } from 'vuex'
export default {
  name: "home",
  components: {
    HelloWorld
  },
  computed: {
    doubleCount(){
      return this.$store.getters.doubleCount
    },
    ...mapState(['count']),
    // equivalente a 
    // count(){
    //   return this.$store.state.count
    // }
  },
  methods: {
    increment() {
      this.$store.dispatch('increment');
    },
    decrement() {
      this.$store.dispatch('decrement');
    }
  }
};
</script>
<style lang="scss">
$phi: 1.618;

.counter{
  text-align: center;
  margin-top: 1.618rem;
  font:1.2rem verdana;
  color:#ddd;
}

button {
  cursor: pointer;
  margin: 0 auto;
  margin-right:1.1618rem;
  padding: #{$phi/2}rem $phi * 1rem;
  // border:1px solid orange;
  font: 1rem verdana;
  border-radius: 30px;
  border: none;
  outline: none;
  &:active {
    background-color: hsl(320, 30%, 30%);
    color: white;
  }
}
</style>

