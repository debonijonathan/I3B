<template>
  <div id="app">
    <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </div>
    
    <!-- qua avviene la render dei componenti -->
    <router-view/>
  </div>
</template>

<style lang="scss">
*, *::before, *::after{
  box-sizing: border-box;
}
html, body{
  padding: 0;
  margin: 0;
  background-image:linear-gradient(to bottom right, hsl(320, 50%, 50%), hsl(320, 30%, 30%));
  background-repeat:no-repeat;
  height:100%;
}
body{
  padding-top:2*1.618rem;
}

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin: 0;
}
</style>
