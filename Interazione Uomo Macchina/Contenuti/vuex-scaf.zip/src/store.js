import Vue from 'vue'
import Vuex from 'vuex'

// introdotti per non avere possibilità di 
// commettere typo
import {
  INCREMENT,
  DECREMENT
} from './mutation-types';

// inietta vuex nell'applicazione e lo store
// in ogni componente, con la proprietà this.$store
Vue.use(Vuex);

export default new Vuex.Store({
  // valore iniziale dello stato, necessario per
  // essere reactive
  state: {
    count: 0
  },
  mutations: {
    // le mutation vengono invocate con commit
    [INCREMENT](state) {
      state.count++;
    },
    [DECREMENT](state) {
      state.count--;
    }
  },
  actions: {
    // le azioni vengono invocate con dispatch
    increment({ commit }) {
      setTimeout(() => {
        commit(INCREMENT);
      }, 2000)
    },
    decrement({ commit }) {
      setTimeout(() => {
        commit(DECREMENT);
      }, 500)
    }
  },
  getters: { // esempio
    doubleCount: (state) => {
      return state.count * 2
    }
  }
})