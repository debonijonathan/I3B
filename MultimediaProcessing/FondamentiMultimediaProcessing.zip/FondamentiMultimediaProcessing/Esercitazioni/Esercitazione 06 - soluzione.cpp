#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv;

string findColor(Scalar bgr);
string findRatio(Size2f size);
int main(int argc, char **argv)
{
	Mat image;
	image = imread("lego.png", CV_LOAD_IMAGE_COLOR); // Read the file
	if (!image.data) // Check for invalid input
	{
		std::cout << "Could not open or find the image" << std::endl;
		return -1;
	}
	int scelta = 0, kSize = 2;
	cout << "Cosa vuoi fare? " << endl
		<< " - 0 = grayscale" << endl
		<< " - 1 = normalBlur" << endl
		<< " - 2 = gaussianBlur" << endl
		<< " - 3 = medianBlur" << endl
		<< " - 4 = bilateralFilter" << endl
		<< " - 5 = Analizza Immagine" << endl;
	cin >> scelta;
	if (scelta > 0 && scelta < 5) {
		while (kSize % 2 == 0)
		{
			cout << "Inserisci la dimensione del kernel (Dispari): " << endl;
			cin >> kSize;
		}
	}
	switch (scelta)
	{
	case 0: {
		Mat gray_image1;
		cvtColor(image, gray_image1, CV_RGB2GRAY);
		imshow("GrayImage", gray_image1);
		break;
	}
	case 1: {
		Mat blur_image;
		blur(image, blur_image, Size(kSize, kSize));
		imshow("BlurImage", blur_image);
		break;
	}
	case 2: {
		Mat gaussianBlur_image;
		GaussianBlur(image, gaussianBlur_image, Size(kSize, kSize), 0, 0);
		imshow("GaussianBlurImage", gaussianBlur_image);
		break;
	}
	case 3: {
		Mat medianBlur_image;
		medianBlur(image, medianBlur_image, kSize);
		imshow("MedianBlurImage", medianBlur_image);
		break;
	}
	case 4: {
		Mat bilateralFilter_image;
		bilateralFilter(image, bilateralFilter_image, kSize, kSize * 2, kSize / 2);
		imshow("BilateralFilterImage", bilateralFilter_image);
		break;
	}
	case 5: {
		// 1. convert in grayscale and compute a threshold
		Mat gray_image;
		cvtColor(image, gray_image, CV_RGB2GRAY);
		double thresh = threshold(gray_image, gray_image, 240, 255, THRESH_BINARY_INV);


		// 2. filter the noise by using one or more morphological filters
		Mat morphologicalFilter_image;
		int erosion_size = 2;
		Mat element = getStructuringElement(MORPH_OPEN, // Faccio un po' di erosione e un filtro misto. 
			Size(2 * erosion_size + 1, 2 * erosion_size + 1),
			Point(erosion_size, erosion_size));
		erode(gray_image, morphologicalFilter_image, element);


		// 3. find out how to use the findContours algorithm and use it to segment the lego blocks
		Mat canny_output;
		vector<vector<Point> > contours;
		vector<Vec4i> hierarchy;
		RNG rng(12345);
		// Detect edges using canny
		Canny(morphologicalFilter_image, canny_output, thresh, thresh * 2, 3);
		// Find Contours
		findContours(morphologicalFilter_image, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));
		// Draw Contours
		Mat drawing = Mat::zeros(canny_output.size(), CV_8UC3);
		for (int i = 0; i < contours.size(); i++)
		{
			Scalar color = Scalar(rng.uniform(0, 255), rng.uniform(0, 255), rng.uniform(0, 255));
			drawContours(drawing, contours, i, color, 2, 8, hierarchy, 0, Point());
		}
		// 4. find a way to understand size and color of each lego block
		vector<double> areas;
		vector<RotatedRect> ellipses;
		vector<Size2f> sizes;
		for (auto &i : contours) {
			areas.push_back(contourArea(i));
			ellipses.push_back(fitEllipse(i));
		}

		vector<vector<Point> > contours_poly(contours.size());
		vector<Rect> boundRect(contours.size());

		for (int i = 0; i < contours.size(); i++) {
			approxPolyDP(Mat(contours[i]), contours_poly[i], 3, true);
			boundRect[i] = boundingRect(Mat(contours_poly[i]));

			// Find barycenter
			int x = boundRect[i].x + (boundRect[i].width) / 2;
			int y = boundRect[i].y + (boundRect[i].height) / 2;

			// 5. put a text label near each block with its properties (size & color)
			putText(image, findRatio(ellipses.at(i).size) + "; " + findColor(image.at<Vec3b>(y, x)), Point(x, y - 90), FONT_ITALIC, 1, Scalar(0, 0, 0));
		}
		imshow("AnalyzedImage", image);
		break;
	}
	}
	waitKey(0);
	return 0;
}

string findColor(Scalar bgr) {
	string name;
	int r = bgr[2];
	int g = bgr[1];
	int b = bgr[0];
	if (r < 5 && g < 5 && b < 5) {
		name = "Black";
	}
	else if (r > 150 && g < 30 && b < 30) {
		name = "Red";
	}
	else if (r > 160 && g > 150 && b < 5) {
		name = "Yellow";
	}
	else if (r < 10 && g > 50 && b > 120) {
		name = "Blue";
	}
	else if (r < 10 && g > 90 && b > 20) {
		name = "Green";
	}
	else {
		name = "White";
	}
	return name;
}

string findRatio(Size2f size) {
	string ratio;
	double width = size.width;
	double height = size.height;
	if (width < 100) {
		ratio = "1x";
	}
	else {
		ratio = "2x";
	}
	if (height < 170) {
		ratio += "2";
	}
	else if (height < 200) {
		ratio += "3";
	}
	else if (height < 280) {
		ratio += "4";
	}
	else {
		ratio += "6";
	}
	return ratio;
}