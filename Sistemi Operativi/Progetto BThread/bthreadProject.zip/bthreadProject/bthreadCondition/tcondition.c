#include <assert.h>
#include <stddef.h>
#include "tcondition.h"
#include "../bthreadLib/bthread_private.h"

/* Inizializza la condition con una coda vuota assicurandosi che sia correttamente instanziata. */
int bthread_cond_init(bthread_cond_t *c, const bthread_condattr_t *attr) {
    assert(c != NULL);
    c->waiting_list = NULL;
    return 0;
}

/* Distrugge la condition controllando che non ci sia nessuno in attesa di esssere svegliato */
int bthread_cond_destroy(bthread_cond_t *c) {
    assert(tqueue_size(c->waiting_list) == 0);
    free(c);
    return 0;
}

/* Per evitare context switch vengono disabilitati i segnali del timer, così facendo ci assicuriamo che le operazioni a seguire
 * vengano svlote in modo atomico. Assumendo che per aspettare su una variabile di condizione occorra essere in possesso di un mutex
 * la prima cosa che andiamo a fare è controllare che il thread chiamante sia effettivamente il proprietario del mutex passato.
 * In caso affermativo il mutex viene rilasciato (affinche altri possano acquisirlo ed eventualmente mettersi a dorimire sulla
 * condition). Infine il thread viene bloccato e messo in coda di attesa, infatti vi è uno yield. Quando il thread viene svegliato
 * la prima cosa che fa sarà riacquisire il mutex che aveva rilascliato prima di mettersi a dormire sulla condizione. */
int bthread_cond_wait(bthread_cond_t *c, bthread_mutex_t *mutex) {
    bthread_block_timer_signal();
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    if (((__bthread_private *) mutex->owner)->tid == bthread->tid) {
        trace("(CONDBLOCKED) %lu %p\n", bthread->tid, c);
        bthread_mutex_unlock(mutex);
        bthread->state = __BTHREAD_BLOCKED;
        tqueue_enqueue(&c->waiting_list, bthread);
        while (bthread->state != __BTHREAD_READY) {
            bthread_yield();
        }
        bthread_mutex_lock(mutex);
    } else {
        bthread_unblock_timer_signal();
    }
    return 0;
}


/* Per evitare context switch vengono disabilitati i segnali del timer, così facendo ci assicuriamo che le operazioni a seguire
 * vengano svlote in modo atomico. Viene recuperato il primo elemento della coda di attesa e viene svegliato.
 * Poi il thread ciamante fa un yield per generosità. */
int bthread_cond_signal(bthread_cond_t *c) {
    bthread_block_timer_signal();
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    trace("(CONDSIGNAL) %lu %p\n", bthread->tid, c);
    __bthread_private *thread = tqueue_pop(&c->waiting_list);
    thread->state = __BTHREAD_READY;
    trace("(READY) %lu\n", thread->tid);
    bthread_yield();
    return 0;
}

/* Per evitare context switch vengono disabilitati i segnali del timer, così facendo ci assicuriamo che le operazioni a seguire
 * vengano svlote in modo atomico. Tutti i thread nella waiting list vengono liberati, successivamente il thread chiamante
 * fa uno yield per fare eseguire i thread appena risvegliati. */
int bthread_cond_broadcast(bthread_cond_t *c) {
    bthread_block_timer_signal();
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    trace("(CONDBROADCAST) %lu %p\n", bthread->tid, c);
    // La dimensioe della coda va calcolata prima in quanto diminuisce ogni volta che faccio pop()
    int size = (int) tqueue_size(c->waiting_list);
    for (int i = 0; i < size; i++) {
        __bthread_private *thread = tqueue_pop(&c->waiting_list);
        thread->state = __BTHREAD_READY;
        trace("(READY) %lu\n", thread->tid);
    }
    bthread_yield();
    return 0;
}