#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include "bthread.h"


bthread_t bthread0, bthread1, bthread2;

unsigned long counterT2 = 0, counterT3 = 0;

void *function0(void *arg) {
    bthread_set_priority(1);
    bthread_printf("Sono il thread 0 con priorita' 1, dormo per un secondo poi uccido tutti...\n");
    bthread_sleep(1000);
    bthread_printf("Sono il thread 0 con priorita' 1, ho dormito per un secondo adesso uccido tutti!!!\n");
    bthread_cancel(bthread1);
    bthread_cancel(bthread2);
}

void *function1(void *arg) {
    bthread_set_priority(2);
    bthread_printf("Sono il thread 1 con priorita' 2, comincio a contare... \n");
    while (1) {
        counterT2++;
        bthread_testcancel();
    }
}

void *function2(void *arg) {
    bthread_set_priority(10);
    bthread_printf("Sono il thread 2 con priorita' 10, comincio a contare... \n");
    while (1) {
        counterT3++;
        bthread_testcancel();
    }
}

int main() {
    srand(time(0));
    //bthread_set_schedulong_routine(bthread_round_robin_scheduling);
    //bthread_set_schedulong_routine(bthread_priority_scheduling);
    //bthread_set_schedulong_routine(bthread_random_scheduling);
    bthread_set_schedulong_routine(bthread_lottery_scheduling);

    bthread_create(&bthread0, NULL, function0, NULL);
    bthread_create(&bthread1, NULL, function1, NULL);
    bthread_create(&bthread2, NULL, function2, NULL);

    printf("t0 %lu | t1 %lu | t2 %lu \n", bthread0, bthread1, bthread2);

    bthread_join(bthread0, NULL);
    bthread_join(bthread1, NULL);
    bthread_join(bthread2, NULL);

    printf("Il thread 1, con priorita' 2, ha contato fino a %lu\nIl thread 2, con priorita' 10 ha contato fino a %lu\n",
           counterT2, counterT3);

    printf("Exiting main. \n");
}