#include <stdint.h>
#include <signal.h>
#include <stdio.h>
#include <sys/time.h>
#include <stdbool.h>
#include "bthread_private.h"
#include "bthread.h"

// GLOBALS

// La variabile tidCounter viene usata per assegnare un id univoco ad ogni singolo thread
static bthread_t tidCounter = 0;
/* La maschera viene dichiarata statica e globale in quanto condivisa fra tutti,
 * viene usanta per bloccare/permettere gli interrupt del timer. (preemption) */
static sigset_t *mask = NULL;

// STATIC

/* Controlla se il thread passato come argomento è nello stato zombie, in caso negativo la funizone ritorna 0.
 * Altrimenti, in caso in la variabile retval non sia NULL (quindi ci aspettiamo un valore di ritorno) il valore di
 * ritorno del thread viene salvato. Successivametne libero la memoria e tolgo il thread dalla coda. Infine ritorno 1. */
static int bthread_check_if_zombie(bthread_t bthread, void **retval) {
    volatile TQueue tQueue = bthread_get_queue_at(bthread);
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *thread = (__bthread_private *) (tqueue_get_data(tQueue));
    if (thread->state != __BTHREAD_ZOMBIE) {
        return 0;
    } else {
        if (retval != NULL) {
            *retval = thread->retval;
        }
        free(tqueue_pop(&tQueue));
        trace("(DESTROY) %lu %p\n", thread->tid, thread->retval);
        scheduler->queue = tQueue;
        return 1;
    }
}

/* Ritorna una vista della coda che parte dal thread specificato come parametro della funzione. Se la coda
 * non contienne questo thread ritorna NULL. */
static TQueue bthread_get_queue_at(bthread_t bthread) {
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    for (int i = 0; i < tqueue_size(scheduler->queue); i++) {
        volatile __bthread_private *thread = (__bthread_private *) tqueue_at_offset(scheduler->queue, i)->data;
        if (thread->tid == bthread) {
            return tqueue_at_offset(scheduler->queue, i);
        }
    }
    return NULL;
}

/* in caso non sia ancora stato inizializzato il timer lo inizializza in modo che venga inviato un segnale periodico
 * che si ripete ogni quanto di tempo. Inoltre viene assegnato come handler del timer la funzione di yield.
 * Cosi facendo abbiamo implementato la preemption. */
static void bthread_setup_timer() {
    static bool initialized = false;
    if (!initialized) {
        signal(SIGVTALRM, (void (*)()) bthread_yield);
        struct itimerval time;
        time.it_interval.tv_sec = 0;
        time.it_interval.tv_usec = QUANTUM_USEC;
        time.it_value.tv_sec = 0;
        time.it_value.tv_usec = QUANTUM_USEC;
        initialized = true;
        setitimer(ITIMER_VIRTUAL, &time, NULL);
    }
}

// SCHEDULER

/* Questa funzione privata (quindi definita in bthread_private.h) è l'implementazione del pattern singleton in C.
 * Serve ad inizializzare una sola volta lo sheduler e a ritornare sempre lo stesso elemento alle chiamate succesive. */
__bthread_scheduler_private *bthread_get_scheduler() {
    // Come se fosse dichiarata all'esterno della funzione in quanto è STATICA!
    static __bthread_scheduler_private *scheduler_private = NULL;
    if (!scheduler_private) {
        scheduler_private = (__bthread_scheduler_private *) malloc(sizeof(__bthread_scheduler_private));
        scheduler_private->queue = NULL;
        scheduler_private->current_item = NULL;
        scheduler_private->current_tid = NULL;
    }
    return scheduler_private;
}

/* Ritorna il tempo attuale in millisecondi. */
double get_current_time_millis() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (tv.tv_sec) * 1000 + (tv.tv_usec) / 1000;
}

/* Crea una maschera, in caso non sia già stata inizializzata, che blocca i segnali del timer. Idealmente serve a
 * disabilitare la preemption in modo che le righe di codice a seguire dlla chiamata di questa funzione eseguano in modo atomico. */
void bthread_block_timer_signal() {
    if (mask == NULL) {
        // creo una maschera e ci metto il segnale SIGVTALRM
        mask = (sigset_t *) malloc(sizeof(sigset_t));
        sigemptyset(mask);
        sigaddset(mask, SIGVTALRM);
    }
    sigprocmask(SIG_BLOCK, mask, NULL);
}

/* Imposta la maschera di default, quindi abilita i segnali del timer passano, in pratica riabilito la preemption. */
void bthread_unblock_timer_signal() {
    sigprocmask(SIG_UNBLOCK, mask, NULL);
}

/* Setta la politica di scheduling dello scheduler, accetta infatti un puntatore a funzione la quale verrà invocata
 * ogni volta che lo scheduler dovrà scegliere quale thread eseguirà. */
void bthread_set_schedulong_routine(void *(*bthread_scheduling_routine)(void *)) {
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    scheduler->scheduling_routine = bthread_scheduling_routine;
}

// Scheduling routines

/* Semplicemente itera la coda ricercando il primo thread con lo stato ready e lo assegna come current item. Inoltre
 * controlla anche se ci sono thread che devono svegliarsi, in caso affermativo li sveglia. */
void *bthread_round_robin_scheduling() {
    trace("(RESCHEDULING)\n");
    // vado a cercare il primo thread libero e lo assegno a current_item
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *tp;
    do {
        scheduler->current_item = tqueue_at_offset(scheduler->current_item, 1);
        tp = (__bthread_private *) tqueue_get_data(scheduler->current_item);
        // se dorme forse è il momento di svegliarsi
        if (tp->state == __BTHREAD_SLEEPING && tp->wake_up_time < get_current_time_millis()) {
            tp->wake_up_time = 0;
            tp->state = __BTHREAD_READY;
            trace("(READY) %lu\n", tp->tid);
        }
    } while (tp->state != __BTHREAD_READY);
}

/* Fa eseguire un thread per tanti quanti di tempo quanto è la sua priorità, quando un thread termina i quanti di tempo schedula il successivo
 * con round dobin. */
void *bthread_priority_scheduling() {
    trace("(RESCHEDULING)\n");
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *currentThread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    if (currentThread->state != __BTHREAD_READY || currentThread->quantumCounter == currentThread->priority) {
        if (currentThread->quantumCounter == currentThread->priority)
            currentThread->quantumCounter = 0;
        // se il thread corrente non è più ready oppure ha eseguito tutti i suoi quanti di tempo ne schedulo un altro con round robin
        bthread_round_robin_scheduling();
    } else {
        // altrimenti incremento il numero di quanti di tempo che ha eseguito finora e lo lascio continuare.
        currentThread->quantumCounter++;
        currentThread->totQuantum++;
    }
}

/* Pesca thread a caso dalla coda finchè non ne trova uno pronto ad eseguire, ogni volta che ne estre uno controlla che non sia
 * il momento di svegliarsi se sta dormendo. */
void *bthread_random_scheduling() {
    trace("(RESCHEDULING)\n");
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *tp;
    do {
        scheduler->current_item = tqueue_at_offset(scheduler->current_item, (rand() % tqueue_size(scheduler->queue)));
        tp = (__bthread_private *) tqueue_get_data(scheduler->current_item);
        // se dorme forse è il momento di svegliarsi
        if (tp->state == __BTHREAD_SLEEPING && tp->wake_up_time < get_current_time_millis()) {
            tp->wake_up_time = 0;
            tp->state = __BTHREAD_READY;
            trace("(READY) %lu\n", tp->tid);
        }
    } while (tp->state != __BTHREAD_READY);
}

/* Implementazione 'semplice' dell'algoritmo di scheduling lottery con spiegazione passo passo. */
void *bthread_lottery_scheduling() {
    trace("(RESCHEDULING)\n");
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    // capienza della 'boccia' da cui estraggo i biglietti della lotteria
    volatile int containerSize = 0;
    // numero di thread ready
    volatile int threadsReady = 0;
    // puntatore per referenziare i thread
    volatile __bthread_private *tp;
    // vado a cercare i thread READY
    for (int i = 0; i < tqueue_size(scheduler->queue); ++i) {
        tp = (__bthread_private *) tqueue_at_offset(scheduler->queue, (unsigned long) i)->data;
        if (tp->state == __BTHREAD_READY) {
            containerSize += tp->priority;
            threadsReady++;
        }
    }
    // istanzio nello stack la 'boccia' e l'indice per accedervi
    volatile bthread_t container[containerSize];
    volatile int ticketsIndex = 0;
    // popolo la 'boccia' con gli id dei thread ready mettendo un numero di biglietti pari alla priorità
    for (int i = 0; i < tqueue_size(scheduler->queue); ++i) {
        // recupero il thread in posizione i
        tp = (__bthread_private *) tqueue_at_offset(scheduler->queue, (unsigned long) i)->data;
        if (tp->state == __BTHREAD_READY) {
            for (int j = 0; j < tp->priority; ++j) {
                container[ticketsIndex] = tp->tid;
                ticketsIndex++;
            }
        } else {
            // se dorme forse è il momento di svegliarsi, alla prossima estrazione della lotteria rientrerà nell'array dei ready
            if (tp->state == __BTHREAD_SLEEPING && tp->wake_up_time < get_current_time_millis()) {
                tp->wake_up_time = 0;
                tp->state = __BTHREAD_READY;
                trace("(READY) %lu\n", tp->tid);
            }
        }
    }
    // effettua l'estrazione'
    volatile int extraction = rand() % containerSize;
    // mette in esecuzione il thread estratto
    scheduler->current_item = bthread_get_queue_at(container[extraction]);
}

// THREAD

/* Crea un nuovo thread inizializzando tutti i suoi parametri ai valori di default, accetta come parametri un riferimento al thread,
 * gli attributi di quest'ultimo (parametro ignorato, viene messo per tenere la compatibilità con pthread),
 * un puntatore a funzione che rappresenta la start routine e infine gli argomenti di quest'ultima. Dopo aver settato questi
 * valori di default aggiunge il thread nella coda dello scheduler. NB: quando viene chiamata questa funzione il thread viene solo instanziato,
 * NON parte. */
int bthread_create(bthread_t *bthread, const bthread_attr_t *attr, void *(*start_routine)(void *), void *arg) {
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *bthread_private = (__bthread_private *) malloc(sizeof(__bthread_private));
    bthread_private->state = __BTHREAD_READY;
    bthread_private->attr = *attr;
    bthread_private->body = start_routine;
    bthread_private->arg = arg;
    bthread_private->stack = NULL;
    bthread_private->wake_up_time = 0;
    bthread_private->cancel_req = 0;
    bthread_private->quantumCounter = 0;
    bthread_private->totQuantum = 0;
    bthread_private->priority = 1;
    tqueue_enqueue(&scheduler->queue, bthread_private);
    *bthread = tidCounter;
    bthread_private->tid = tidCounter;
    tidCounter++;
    trace("(CREATE) %lu\n", bthread_private->tid);
    return 0;
}

/* Imposta la priorità del thread chiamante se questa è maggiore di zero. */
void bthread_set_priority(int p) {
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *current = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    if (p > 0) {
        current->priority = p;
    }
}

/* Nell'attesa che termini il thread specificato come parametro (che raggiunga lo stato zombie), schedula e fa eseguire tutti i thread nella coda.
 * Per prima coda vengono dibalilitati gli interrupt del timer per grarantire che le operazioni di scheduling vengano eseguite in modo atomico.
 * Imposta come elemeto corrente la testa della coda (perchè la scheduling routine parte dall'elelemto corrente).
 * Viene salvato il contesto dello schedueler per la prossima esecuzione.
 * Controlla che il thread passato come argomento non abbia finito l'esecuzione.
 * Sceglie il prossimo thread.
 * Se è la prima volta che esegue viene definito il suo stack e viene chiamata la sua start routine altrimenti viene semplicemente
 * ripristinato il suo contesto così che possa eseguire. */
int bthread_join(bthread_t bthread, void **retval) {
    trace("(INSCHEDULER)\n");
    bthread_block_timer_signal();
    bthread_setup_timer();
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    // Imposto la politica di scheduling di default
    if (scheduler->scheduling_routine == NULL)
        bthread_set_schedulong_routine(bthread_round_robin_scheduling);
    scheduler->current_item = scheduler->queue;
    save_context(scheduler->context);
    if (bthread_check_if_zombie(bthread, retval)) return 0;
    // Ricerco il primo thread con lo stato ready usando la politica di scheduling richiesta dall'utente
    scheduler->scheduling_routine();
    __bthread_private *tp = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    // Restore context or setup stack and perform first call
    if (tp->stack) {
        bthread_unblock_timer_signal();
        restore_context(tp->context);
    } else {
        tp->stack = (char *) malloc(sizeof(char) * STACK_SIZE);
#if __x86_64__
        asm __volatile__("movq %0, %%rsp"::
        "r"((intptr_t) (tp->stack + STACK_SIZE - 1)));
#else
        asm __volatile__("movl %0, %%esp" ::
        "r"((intptr_t) (tp->stack + STACK_SIZE - 1)));
#endif
        bthread_unblock_timer_signal();
        // chiamo la start routine del thread
        bthread_exit(tp->body(tp->arg));
    }
}

/* Salva il contesto del thread chiamante, poi ripristina il contesto dello scheduler (gli passa la palla).
 * Il tutto viene eseguito in modo atomico disabilitando gli interrupt e riabilitandoli alla fine. */
void bthread_yield() {
    bthread_block_timer_signal();
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *thread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    trace("(YIELD) %lu\n", thread->tid);
    // Quando un thread si risveglia, ripartirà al punto in cui è stato salvato il suo contesto, ovvero qui.
    // Come facico a capire se il thread si è appena svegliato e quindi deve eseguire oppure se ha appena eseguito e deve passare la
    // palla allo scheduler? guardo il valore di ritorno. Se 0 vuol dire che il thread ha appena eseguito e deve passare la palla,
    // altrimenti vuol dire che è appena stato schedulato per essere eseguito.
    if (save_context(thread->context) == 0)
        restore_context(scheduler->context);
    bthread_unblock_timer_signal();
}

/* Mette a dormire il thread chiamante per il numero di ms passati. In pratica aggiorno lo stato del thread e imposto la sua sveglia
 * all'ora di sistema sommata con i millisecondi che dovrà dormire. poi il thread fa uno yield per mettersi a dormire. */
void bthread_sleep(double ms) {
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *thread = (__bthread_private *) (scheduler->current_item->data);
    thread->state = __BTHREAD_SLEEPING;
    trace("(SLEEPING) %lu\n", thread->tid);
    thread->wake_up_time = get_current_time_millis() + ms;
    bthread_yield();
}

/* Va a settare il flag di cancellazione del thread passsato, se quest'ultimo fa testcancel termina. */
int bthread_cancel(bthread_t bthread) {
    volatile __bthread_private *thread = (__bthread_private *) bthread_get_queue_at(bthread)->data;
    thread->cancel_req = 1;
    trace("(CANCEL) %lu\n", thread->tid);
}

/* Va a controllare se deve suicidarsi, perchè se ha la flag di cancellazione settata termina. */
void bthread_testcancel(void) {
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *thread = (__bthread_private *) (scheduler->current_item->data);
    trace("(TEST_CANCEL) %lu\n", thread->tid);
    if (thread->cancel_req) {
        bthread_exit(-1);
    }
}

/* Imposta lo stato del thread chiamante a zombie (nella join, verra fatto un controllo se zombie e in caso affermativo il
 * thread viene fisicamente cancellato). Inoltre salva il valore di ritorno in retval. */
void bthread_exit(void *retval) {
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *t = tqueue_get_data(scheduler->current_item);
    trace("(ExIT) %lu %p\n", t->tid, t->retval);
    t->state = __BTHREAD_ZOMBIE;
    t->retval = retval;
    bthread_yield();
}

/* La funzione printf non è thread-safe, ne definiamo una apposita che lavora in modo atomico e che permette ai thread di stampare
 * su stdout. */
void bthread_printf(const char *format, ...) {
    bthread_block_timer_signal();
    va_list args;
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
    bthread_unblock_timer_signal();
}

/* NON da implementare, idealmente verifica che tutte le risorse vengano liberate al termine dell'esecuizone. */
void bthread_cleanup() {

}