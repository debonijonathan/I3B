//#include <stdio.h>
//#include <stdlib.h>
//#include <unistd.h>
//#include <signal.h>
//#include <time.h>
//#include "bthread.h"
//#include "../bthreadCondition/tcondition.h"
//#include "../bthreadMutex/tmutex.h"
//
//bthread_t bthread0, bthread1, bthread2, bthread3;
//
//bthread_cond_t sharedCondtion;
//bthread_mutex_t sharedMutex;
//
//void *function0(void *arg) {
//    bthread_printf("sono il thread 0 mi metto a dormire per 1 second0 poi faccio un signal.\n");
//    bthread_sleep(1000);
//    bthread_printf("sono il thread 0 faccio un signal.\n");
//    bthread_cond_signal(&sharedCondtion);
//    bthread_printf("sono il thread 0 mi metto a dormire per 1 second0 poi faccio un signal.\n");
//    bthread_sleep(1000);
//    bthread_printf("sono il thread 0 faccio un signal.\n");
//    bthread_cond_signal(&sharedCondtion);
//    bthread_printf("sono il thread 0 mi metto a dormire per 1 second0 poi faccio un signal.\n");
//    bthread_sleep(1000);
//    bthread_printf("sono il thread 0 faccio un signal.\n");
//    bthread_cond_signal(&sharedCondtion);
////    bthread_printf("sono il thread 0 mi metto a dormire per altri 2 secondi poi faccio un broadcast\n");
////    bthread_sleep(2000);
////    bthread_printf("sono il thread 0 faccio un broadcast.\n");
////    bthread_cond_broadcast(&sharedCondtion);
//}
//
//void *function1(void *arg) {
//    bthread_printf("sono il thread 1 acquisisco il mutex e mi metto a dormire sulla condizione.\n");
//    bthread_mutex_lock(&sharedMutex);
//    bthread_cond_wait(&sharedCondtion, &sharedMutex);
//    bthread_printf("sono il thread 1 mi sono svegliato dopo che qualcuno ha fatto un signal/broadcast.\n");
//}
//
//void *function2(void *arg) {
//    bthread_printf("sono il thread 2 acquisisco il mutex e mi metto a dormire sulla condizione.\n");
//    bthread_mutex_lock(&sharedMutex);
//    bthread_cond_wait(&sharedCondtion, &sharedMutex);
//    bthread_printf("sono il thread 2 mi sono svegliato dopo che qualcuno ha fatto un signal/broadcast.\n");
//}
//
//void *function3(void *arg) {
//    bthread_printf("sono il thread 3 acquisisco il mutex e mi metto a dormire sulla condizione.\n");
//    bthread_mutex_lock(&sharedMutex);
//    bthread_cond_wait(&sharedCondtion, &sharedMutex);
//    bthread_printf("sono il thread 3 mi sono svegliato dopo che qualcuno ha fatto un signal/broadcast.\n");
//}
//
//int main() {
//    srand(time(0));
//
//    bthread_cond_init(&sharedCondtion, NULL);
//
//    bthread_create(&bthread0, NULL, function0, NULL);
//    bthread_create(&bthread1, NULL, function1, NULL);
//    bthread_create(&bthread2, NULL, function2, NULL);
//    bthread_create(&bthread3, NULL, function3, NULL);
//
//    // TODO: Non funzonano le condition, trova il problema!
//
//    printf("t0 %lu | t1 %lu | t2 %lu | t3 %lu \n", bthread0, bthread1, bthread2, bthread3);
//
//    bthread_join(bthread0, NULL);
//    bthread_join(bthread1, NULL);
//    bthread_join(bthread2, NULL);
//    bthread_join(bthread3, NULL);
//
//    printf("Exiting main. \n");
//}