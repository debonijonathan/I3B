#include <assert.h>
#include "tmutex.h"
#include "../bthreadLib/bthread_private.h"

/* Inizializza un mutex con una coda vuota e nessun proprietario, inoltre controlla che sia correttamente istanziato. */
int bthread_mutex_init(bthread_mutex_t *m, const bthread_mutexattr_t *attr) {
    assert(m != NULL);
    m->owner = NULL;
    m->waiting_list = NULL;
    return 0;
}

/* Controlla che il mutex non sia lockato da nessuno e che non vi sia nessuno in attesa di acquisirlo, passati questi
 * controlli libera la memoria. */
int bthread_mutex_destroy(bthread_mutex_t *m) {
    assert(m->owner == NULL);
    assert(tqueue_size(m->waiting_list) == 0);
    free(m);
    return 0;
}

/* Per evitare context switch vengono disabilitati i segnali del timer, così facendo ci assicuriamo che le operazioni a seguire
 * vengano svlote in modo atomico. Viene recuperato il thread chiamante tramite lo scheduler e se il mutex è libero il thread ne
 * diventa il proprietario. Poi vengono riabilitati gli interrupt e il thread corrente continua la sua esecuzione. Se invece il mutex è
 * bloccato il thread corrente verrà messo nella coda di attesa e non gli sarà permesso di continuare l'esecuzione, infatti come ultima
 * operazione si fa uno yeld. */
int bthread_mutex_lock(bthread_mutex_t *m) {
    bthread_block_timer_signal();
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    if (m->owner == NULL) {
        m->owner = (void *) bthread;
        trace("(MUTACQUIRE) %lu %p\n", bthread->tid, m);
        bthread_unblock_timer_signal();
    } else {
        bthread->state = __BTHREAD_BLOCKED;
        trace("(MUTBLOCKED) %lu %p\n", bthread->tid, m);
        tqueue_enqueue(&m->waiting_list, (void *) bthread);
        // il mutex è già acquisito quindi faccio uno yield, se quando riprendo non posso acncora acquisire il mutex lo rifaccio.
        while (bthread->state != __BTHREAD_READY) {
            bthread_yield();
        };
    }
    return 0;
}

/* Molto simile alla funzione precedente, con la differenza che se il mutex è già bloccato il thread non viene sospeso ma semplicemente
 * viene ritornato un valore di -1 che indica che il thread chiamante non è riuscito ad acquisire il mutex. */
int bthread_mutex_trylock(bthread_mutex_t *m) {
    bthread_block_timer_signal();
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    if (m->owner == NULL) {
        m->owner = bthread;
        trace("(MUTACQUIRE) %lu %p\n", bthread->tid, m);
        bthread_unblock_timer_signal();
    } else {
        trace("(MUTFAIL) %lu %p\n", bthread->tid, m);
        bthread_unblock_timer_signal();
        return -1;
    }
    return 0;
}

/* Sblocca il mutex m. Come sempre, per eseguire in modo atomico, vengono disabilitati gli interrupt del tiemr.
 * Successivamente, se il thread chiamante è l'attuale proprietario del mutex quest'ultimo viene rilasciato.
 * In caso ci sia uno o più thread in attesa di acquisire il mutex questo viene assegnato al primo thread che lo
 * aveva richiesto, ovvero quello in testa alla coda di attesa. */
int bthread_mutex_unlock(bthread_mutex_t *m) {
    bthread_block_timer_signal();
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    assert(m->owner != NULL);
    // controllo che chi ha chiamato l'unclock sia l'attuale proprietario del mutex
    assert(m->owner == tqueue_get_data(scheduler->current_item));
    trace("(MUTRELEASE) %lu %p\n", ((__bthread_private *) m->owner)->tid, m);
    // prendo il primo che ha fatto un lock senza successo (ed è finito nella coda di attesa)
    volatile __bthread_private *unlock = tqueue_pop(&m->waiting_list);
    if (unlock != NULL) {
        m->owner = unlock;
        // setto lo stato a ready da blocked e faccio yield
        unlock->state = __BTHREAD_READY;
        trace("(READY) %lu\n", unlock->tid);
        bthread_yield();
        return 0;
    } else {
        m->owner = NULL;
    }
    bthread_unblock_timer_signal();
    return 0;
}