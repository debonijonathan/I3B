#include "tqueue.h"
#include <stdlib.h>
#include <stdio.h>

/* Aggiunge un nuovo elemento in fondo alla lista */
// q punta alla testa della lista quindi se vogliamo operare sulla testa della lista dobbiamo deferenziare q. quindi (*q) equivale alla testa!
unsigned long int tqueue_enqueue(TQueue *q, void *data) {
    if ((*q) == NULL) {
        // La coda e' vuota, la instanzio e aggiungo l'elemento
        (*q) = (TQueue) malloc(sizeof(TQueue));
        (*q)->data = data;
        (*q)->next = (*q);
        return 0;
    }
    //La coda non e' vuota, trovo la fine
    TQueueNode *head = (*q);
    unsigned long int position = tqueue_size((*q)) - 1;
    TQueueNode *tail = tqueue_at_offset((*q), position);
    // aggiungo l'elemento in coda e faccio puntare la testa dal nuovo elemento aggiunto alla testa della lista
    TQueueNode *new = malloc(sizeof(TQueueNode));
    tail->next = new;
    new->data = data;
    new->next = head;
    // ritorno la posizione dell'elemento appena aggiunto
    return ++position;
}

/* Rimuove e ritorna i dati contenuti nella testa, NULL se la coda è vuota, e rimuove la testa */
void *tqueue_pop(TQueue *q) {
    if ((*q) == NULL)
        return NULL;
    // Mi salvo i dati da ritornare
    void *data = (*q)->data;
    // La vecchia testa è l'elemento puntato da (*q)
    TQueueNode *oldHead = (*q);
    // La nuova testa sarà l'elemento successivo di quella vecchia
    TQueueNode *newHead = oldHead->next;
    // Controllo che la coda non si sia svuotata (è il caso in cui faccio la pop dell'ultimo valore)
    if (oldHead == newHead) {
        free(oldHead);
        (*q) = NULL;
    } else {
        // Se la coda ha più di un elemento vado a recuperare l'ultimo elemento
        TQueueNode *tail = tqueue_at_offset(oldHead, (tqueue_size(oldHead) - 1));
        // faccio puntare l'ultimo elemento alla nuova testa
        tail->next = newHead;
        // Aggiorno il puntatore alla coda dopo aver effettuato tutte le modifiche
        (*q) = newHead;
        // cancello la vecchia testa
        free((oldHead));
    }
    // ritorno i dati che erano nella vecchia testa
    return data;
}

/* Ritorna il numero di elementi presenti nella coda */
unsigned long int tqueue_size(TQueue q) {
    // Se la coda è vuota ritorno 0
    if (q == NULL)
        return 0;
    TQueueNode *head = q;
    TQueueNode *current = q;
    unsigned long int size = 1;
    // Altrimenti itero partendo dalla testa e smetto quando la ritrovo (è una coda circolare)
    while (current->next != head) {
        current = current->next;
        size++;
    }
    return size;
}

/* Ritorna l'elemento in posizione offset partendo dall'elemento q */
TQueue tqueue_at_offset(TQueue q, unsigned long int offset) {
    if (q == NULL)
        return NULL;
    unsigned long int position = 0;
    TQueueNode *current = q;
    // Itero fino alla posizione specificata poi ritorno l'elemento corrispondente
    while (position != offset) {
        current = current->next;
        ++position;
    }
    return current;
}

/* ritorna i dati di q */
void *tqueue_get_data(TQueue q) {
    if (q == NULL)
        return NULL;
    return q->data;
}

/* questo metodo serve unicamente per i test, stampa una coda di INTERI */
void tqueue_printInteger(TQueue q) {
    if (q == NULL) {
        printf("[ ]");
    } else {
        TQueueNode *head = q;
        TQueueNode *current = q;
        printf("[");
        // Altrimenti itero finche non ritrovo la testa
        do {
            printf(" %d, ", *((int *) (current->data)));
            current = current->next;
        } while (current != head);
        printf("]\n");
    }
}