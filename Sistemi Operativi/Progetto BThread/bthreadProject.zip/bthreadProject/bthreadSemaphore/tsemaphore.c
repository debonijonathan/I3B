#include <stddef.h>
#include <assert.h>
#include <stdlib.h>
#include "tsemaphore.h"
#include "../bthreadLib/bthread_private.h"

/* Inizializza il semaforo controllando che sia correttamente instanziato, specificando il numero di thread che possono
 * passare e crea una coda vuota. */
int bthread_sem_init(bthread_sem_t *m, int pshared, int value) {
    assert(m != NULL);
    m->value = value;
    m->waiting_list = NULL;
    return 0;
}

/* Si assicura che seiano passati tutti e che la coda di attesa sia vuota poi libera la memoria. */
int bthread_sem_destroy(bthread_sem_t *m) {
    assert(m->value == 0);
    assert(tqueue_size(m->waiting_list) == 0);
    free(m);
    return 0;
}

/* Per evitare context switch vengono disabilitati i segnali del timer, così facendo ci assicuriamo che le operazioni a seguire
 * vengano svlote in modo atomico. Viene recuperato il thread chiamante, successivamente viene decrementato il valore del
 * semaforo. Se quest'ultimo secnde sotto lo 0 il thread chiamante verrà bloccato e sarà costretto a fare uno yeld.
 * Altimenti potrà continuare l'esecuizone. */
int bthread_sem_wait(bthread_sem_t *m) {
    bthread_block_timer_signal();
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    trace("(SEMWAIT) %lu %p %d\n", bthread->tid, m, m->value);
    m->value--;
    if (m->value < 0) {
        bthread->state = __BTHREAD_BLOCKED;
        trace("(SEMBLOCKED) %lu %p\n", bthread->tid, m);
        tqueue_enqueue(&m->waiting_list, bthread);
        // Non posso passare, quando qualcuno farà un post, se sono il primo della coda, passerò.
        while (bthread->state != __BTHREAD_READY) {
            bthread_yield();
        };
    } else {
        trace("(SEMACQUIRE) %lu %p %d\n", bthread->tid, m, m->value);
        bthread_unblock_timer_signal();
    }
    return 0;
}

/* Anche qui per evitare context switch vengono disabilitati i segnali del timer, così facendo ci assicuriamo che le operazioni a seguire
 * vengano svlote in modo atomico. In seguito viene incrementato il valore del semaforo e se c'è un thread in attesa di passare viende lasciato eseguire. */
int bthread_sem_post(bthread_sem_t *m) {
    bthread_block_timer_signal();
    m->value++;
    volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    volatile __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    trace("(SEMPOST) %lu %p %d\n", bthread->tid, m, m->value);
    volatile __bthread_private *unlock = tqueue_pop(&m->waiting_list);
    if (unlock != NULL) {
        unlock->state = __BTHREAD_READY;
        trace("(READY) %lu\n", unlock->tid);
        bthread_yield();
    } else {
        bthread_unblock_timer_signal();
    }
    return 0;
}