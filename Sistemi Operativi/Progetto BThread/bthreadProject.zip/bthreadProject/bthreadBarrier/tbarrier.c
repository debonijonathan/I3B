#include <assert.h>
#include <stddef.h>
#include "tbarrier.h"
#include "../bthreadLib/bthread_private.h"

/* Inizializza una barriera controllando che non sia NULL, poi imposta la dimensione della barriera a count,
 * quando il numero di thread in coda raggiunge questo valore li sblocca tutti. */
int bthread_barrier_init(bthread_barrier_t *b, const bthread_barrierattr_t *attr, unsigned count) {
    assert(b != NULL);
    b->barrier_size = count;
    b->count = 0;
    b->waiting_list = NULL;
    return 0;
}

/* Controlla che non ci sia nessuno ad aspettare alla barirera, poi libera la memoria occupata da quest'ultima. */
int bthread_barrier_destroy(bthread_barrier_t *b) {
    assert(b->count == 0);
    assert(tqueue_size(b->waiting_list) == 0);
    free(b);
    return 0;
}

/* Per evitare context switch vengono disabilitati i segnali del timer, così facendo ci assicuriamo che le operazioni a seguire
 * vengano svlote in modo atomico. Successivamente controlliamo che il thread chiamante non sia l'ultimo che stiamo aspettando,
 * in caso facciamo ripartire tutti e resettiamo la barriera. Altrimenti blocchiamo il thread chiamante e lo mettiamo in lista
 * incrementando il numero di thread in coda alla barriera. Infine il thread corrente fa yeld per mettersi a "dormire". */
int bthread_barrier_wait(bthread_barrier_t *b) {
    bthread_block_timer_signal();
    if (b->count == (b->barrier_size - 1)) {
        int size = (int) tqueue_size(b->waiting_list);
        for (int i = 0; i < size; i++) {
            __bthread_private *thread = tqueue_pop(&b->waiting_list);
            thread->state = __BTHREAD_READY;
            trace("(READY) %lu\n", thread->tid);
        }
        b->count = 0;
    } else {
        volatile __bthread_scheduler_private *scheduler = bthread_get_scheduler();
        volatile __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
        bthread->state = __BTHREAD_BLOCKED;
        tqueue_enqueue(&b->waiting_list, bthread);
        b->count++;
        while (bthread->state != __BTHREAD_READY)
            bthread_yield();
    }
    return 0;
}